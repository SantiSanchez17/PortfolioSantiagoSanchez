//Document JavaScript
var AD=0;
var BD=0;
var CD=0;
var DD=0;
var ED=0;
var FD=0;
//conatdor


function iniciar () {
	// inicia el programa
	guia=document.getElementById("pregunta1");
	salir=document.getElementById("x");
	guia.addEventListener("click",()=>{
		window.open("Guia.html","_Target");
	},false);
	salir.addEventListener("click",()=>{
		window.open("Menu.html","_Top");
	},false);

	quimico1=document.getElementById('r1');
	quimico2=document.getElementById('r2');
	quimico3=document.getElementById('r3');
	quimico4=document.getElementById('r4');
	quimico5=document.getElementById('r5');
	quimico6=document.getElementById('r6');
	pregunta=document.getElementById('pregunta');
	respuestas=document.getElementById('respuestas');
	function ocultarV(){
		correcto=document.getElementById("correcto").style.display="none";
	}
	function ocultarD(){
		incorrecto=document.getElementById("incorrecto").style.display="none";
	}
	function mostrarD(){
		incorrecto=document.getElementById("incorrecto").style.display="block";
		setTimeout(ocultarD,2000);
	}
	function mostrarV(){
		correcto=document.getElementById("correcto").style.display="block";
		setTimeout(ocultarV,2000);
	}

	quimico1.addEventListener("click",()=>{
		alert("Pregunta 1");
		pregunta.style.display="block";
		respuestas.style.display="block";
		pregunta.innerHTML = "¿Cual es el compuesto de acido sulfurico?";
		respuestas.innerHTML = "<img src='img/A.png'id='A'/>H2SO4<img src='img/B.png'id='B'/>O6S3H2<img src='img/C.png'id='C'/>H2O4S";
		//respuesta es la "A"
		A=document.getElementById("A");
		B=document.getElementById("B");
		C=document.getElementById("C");
		A.addEventListener("click",()=>{
			mostrarV();
			pregunta.style.display="none";
			respuestas.style.display="none";
			AD++;
			if (AD > 0 && BD > 0 && CD > 0 && DD > 0 && ED > 0 && FD > 0){
				window.open("ganador.html", "_Top");
			}
			console.log(AD);
		},false);
		B.addEventListener("click",()=>{
			mostrarD();
		},false);
		C.addEventListener("click",()=>{
			mostrarD();
		},false);
	},false);

	quimico2.addEventListener("click",()=>{
		alert("Pregunta 2");
		pregunta.style.display="block";
		respuestas.style.display="block";
		pregunta.innerHTML = "¿Cual es la forma sistematica del SeO3?";
		respuestas.innerHTML = "<img src='img/A.png'id='A'/>Dioxido de Se<img src='img/B.png'id='B'/>Trioxido de O<img src='img/C.png'id='C'/>Trioxido de Se";
		//respuesta es la "C"
		A=document.getElementById("A");
		B=document.getElementById("B");
		C=document.getElementById("C");	
		A.addEventListener("click",()=>{
			mostrarD();
		},false);
		B.addEventListener("click",()=>{
			mostrarD();
		},false);
		C.addEventListener("click",()=>{
			mostrarV();
			pregunta.style.display="none";
			respuestas.style.display="none";
			BD++;
			if (AD > 0 && BD > 0 && CD > 0 && DD > 0 && ED > 0 && FD > 0){
				window.open("ganador.html", "_Top");
			}
			console.log(BD);
		},false);
	},false);
	quimico3.addEventListener("click",()=>{
		alert("Pregunta 3");
		pregunta.style.display="block";
		respuestas.style.display="block";
		pregunta.innerHTML = "¿Cuantos gramos tiene un atomo de Cu?";
		respuestas.innerHTML = "<img src='img/A.png'id='A'/>40g<img src='img/B.png'id='B'/>63g<img src='img/C.png'id='C'/>63kg";
		//respuesta es la "B"
		A=document.getElementById("A");
		B=document.getElementById("B");
		C=document.getElementById("C");
		A.addEventListener("click",()=>{
			mostrarD();
		},false);
		B.addEventListener("click",()=>{
			mostrarV();
			pregunta.style.display="none";
			respuestas.style.display="none";
			CD++;
			if (AD > 0 && BD > 0 && CD > 0 && DD > 0 && ED > 0 && FD > 0){
				window.open("ganador.html", "_Top");
			}
			console.log(CD);
		},false);
		C.addEventListener("click",()=>{
			mostrarD();
		},false);
	},false);
	quimico4.addEventListener("click",()=>{
		alert("Pregunta 4");
		pregunta.style.display="block";
		respuestas.style.display="block";
		pregunta.innerHTML = "¿Cuales es el compuesto correcto del Dioxido de carbono?";
		respuestas.innerHTML = "<img src='img/A.png'id='A'/>C2O<img src='img/B.png'id='B'/>C2O3<img src='img/C.png'id='C'/>CO2";
		//respuesta es la "C"
		A=document.getElementById("A");
		B=document.getElementById("B");
		C=document.getElementById("C");
		A.addEventListener("click",()=>{
			mostrarD();
		},false);
		B.addEventListener("click",()=>{
			mostrarD();
		},false);
		C.addEventListener("click",()=>{
			mostrarV();
			pregunta.style.display="none";
			respuestas.style.display="none";
			DD++;
			if (AD > 0 && BD > 0 && CD > 0 && DD > 0 && ED > 0 && FD > 0){
				window.open("ganador.html", "_Top");
			}
			console.log(DD);
		},false);
	},false);
	quimico5.addEventListener("click",()=>{
		alert("Pregunta 5");
		pregunta.style.display="block";
		respuestas.style.display="block";
		pregunta.innerHTML = "¿Cual es la forma sistematica del Au2O3?";
		respuestas.innerHTML = "<img src='img/A.png'id='A'/>Dioxido de Au<img src='img/B.png'id='B'/>Trioxido de Au<img src='img/C.png'id='C'/>Trioxido de Oro";
		//Respuestas es la "B"
		A=document.getElementById("A");
		B=document.getElementById("B");
		C=document.getElementById("C");
		A.addEventListener("click",()=>{
			mostrarD();
		},false);
		B.addEventListener("click",()=>{
			mostrarV();
			pregunta.style.display="none";
			respuestas.style.display="none";
			ED++;
			if (AD > 0 && BD > 0 && CD > 0 && DD > 0 && ED > 0 && FD > 0){
				window.open("ganador.html", "_Top");
			}
			console.log(ED);
		},false);
		C.addEventListener("click",()=>{
			mostrarD();
		},false);
	},false);
	quimico6.addEventListener("click",()=>{
		alert("Pregunta 6");
		pregunta.style.display="block";
		respuestas.style.display="block";
		pregunta.innerHTML = "Cuantos gramos tiene un atomo de Na?";
		respuestas.innerHTML = "<img src='img/A.png'id='A'/>23g<img src='img/B.png'id='B'/>22.99lb<img src='img/C.png'id='C'/>23ml";
		//Respuesta es la "A"
		A=document.getElementById("A");
		B=document.getElementById("B");
		C=document.getElementById("C");
		A.addEventListener("click",()=>{
			mostrarV();
			pregunta.style.display="none";
			respuestas.style.display="none";
			FD++;
			console.log(FD);
			if (AD > 0 && BD > 0 && CD > 0 && DD > 0 && ED > 0 && FD > 0){
				window.open("ganador.html", "_Top");
			}
		},false);
		B.addEventListener("click",()=>{
			mostrarD();
		},false);
		C.addEventListener("click",()=>{
			mostrarD();
		},false);
	},false);
	respuestas.innerHTML = "";
	pregunta.innerHTML="";
	if (AD > 0 && BD > 0 && CD > 0 && DD > 0 && ED > 0 && FD > 0){
		window.open("ganador.html", "_Top");
	}
}
window.addEventListener("load",iniciar,false);