//Javascript Document
function iniciar(){
	console.log ("Se inicia el programa");
	

    btnRegresar = document.getElementById ("Regresar");

    btnRegresar.addEventListener("click", Regresar, false);
}
function Regresar(){
	console.log ("Presionaste el botón Regresar");
	window.open("Menu.html", "_Top");
}

window.addEventListener("load", iniciar, false);