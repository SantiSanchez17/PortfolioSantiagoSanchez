
var contador = 0;
var x;
var txtRespuesta1;
var txtRespuesta2;
var Solucion1;
var Solucion2;

function iniciar(){
	console.log ("Se inicia el programa");
	
	txtRespuesta1 = document.getElementById("Respuesta1");
	txtRespuesta2 = document.getElementById("Respuesta2");
	btnGuia = document.getElementById("Guia");
	btnSalir = document.getElementById("Salir");
	btnCon = document.getElementById("Con");
	respon1 = document.getElementById("respon1");
	respon2 = document.getElementById("respon2");
	Habla = document.getElementById("Habla");
	

	btnGuia.addEventListener("click", Guia, false);
	btnSalir.addEventListener("click", Salir, false);
	btnCon.addEventListener("click", Consulta, false);

	function ocultarV(){
		correcto=document.getElementById("correcto").style.display="none";
	}
	function ocultarD(){
		incorrecto=document.getElementById("incorrecto").style.display="none";
	}
	function mostrarD(){
		incorrecto=document.getElementById("incorrecto").style.display="block";
		setTimeout(ocultarD,2000);
	}
	function mostrarV(){
		correcto=document.getElementById("correcto").style.display="block";
		setTimeout(ocultarV,2000);
	}

	function aleatorio(min,max){
	var resultado;
	resultado=Math.floor(Math.random()*((max-min)+1)+min);
	return resultado;
	}
	actaulizar();
	function actaulizar(){
		x = aleatorio(1,6);
		console.log(x);
		if (x == 1){
			Habla.innerHTML="<img src='img/nivel-2/habla"+x+".png'>"
			respon1.innerHTML = "H";
			respon2.innerHTML = "O";
			Solucion1 = 2;
			Solucion2 = 16;
		}
		if (x == 2){
			Habla.innerHTML="<img src='img/nivel-2/habla"+x+".png'>"
			respon1.innerHTML = "Na";
			respon2.innerHTML = "Cl";
			Solucion1 = 23;
			Solucion2 = 35;
		}
		if (x == 3){
			Habla.innerHTML="<img src='img/nivel-2/habla"+x+".png'>"
			respon1.innerHTML = "Fe";
			respon2.innerHTML = "O";
			Solucion1 = 2;
			Solucion2 = 3;
		}
		if (x == 4){
			Habla.innerHTML="<img src='img/nivel-2/habla"+x+".png'>"
			respon1.innerHTML = "C";
			respon2.innerHTML = "O";
			Solucion1 = 1;
			Solucion2 = 2;
		}
		if (x == 5){
			Habla.innerHTML="<img src='img/nivel-2/habla"+x+".png'>"
			respon1.innerHTML = "Ti";
			respon2.innerHTML = "O";
			Solucion1 = 2;
			Solucion2 = 3;
		}
		if (x == 6){
			Habla.innerHTML="<img src='img/nivel-2/habla"+x+".png'>"
			respon1.innerHTML = "Cu";
			respon2.innerHTML = "O";
			Solucion1 = 126;
			Solucion2 = 16;
		}
	}
	
	function Consulta(){
	if (txtRespuesta1.value == Solucion1 && txtRespuesta2.value == Solucion2){
		//alert("¡CORRECTO!");
		txtRespuesta1.value = "";
		txtRespuesta2.value = "";
		contador++;
		mostrarV();
		console.log(contador);
		actaulizar();
		if (contador == 3){
			window.open("Selector de niveles.html", "_Top");
		}
	}else{
		//alert("INTENTA DE NUEVO");
		mostrarD();
	}
}
}
function Guia(){
	console.log ("Presionaste el botón Guia");
	window.open("Guia.html", "_Target");
}
function Salir(){
	console.log ("Presionaste el botón Salir");
	window.open("Menu.html", "_Top");
}

window.addEventListener("load", iniciar, false);