
function tiempo () {
	setTimeout(espera,3000);
}
function espera(){
	window.open("Menu.html","_Top");
}



window.addEventListener("load",tiempo,false);