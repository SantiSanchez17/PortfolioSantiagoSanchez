//Javascript Document
function iniciar(){
	console.log ("Se inicia el programa");
	

    btnSalir = document.getElementById ("Salir");
    btnNivel1 = document.getElementById ("Nivel1");
    btnNivel2 = document.getElementById ("Nivel2");
    btnNivel3 = document.getElementById ("Nivel3");

    btnSalir.addEventListener("click", Salir, false);
    btnNivel1.addEventListener("click", Nivel1, false);
    btnNivel2.addEventListener("click", Nivel2, false);
    btnNivel3.addEventListener("click", Nivel3, false);
}
function Salir(){
	console.log ("Presionaste el botón Salir");
    window.open("Menu.html", "_Top");
}
function Nivel1(){
	console.log ("Presionaste el botón Nivel 1");
    window.open("Nivel1.html", "_Top");
}
function Nivel2(){
	console.log ("Presionaste el botón Nivel 2");
    window.open("Nivel2.html", "_Top");
}
function Nivel3(){
	console.log ("Presionaste el botón Nivel 3");
    window.open("Nivel3.html", "_Top");
}

window.addEventListener("load", iniciar, false);