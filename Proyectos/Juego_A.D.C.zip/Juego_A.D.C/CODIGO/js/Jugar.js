alert("Bienvenido");


function tiempo () {
	setTimeout(espera,1000);
}
function espera(){
	window.open("CODIGO/carga1.html","_Top");
}
window.addEventListener("load",tiempo,false);