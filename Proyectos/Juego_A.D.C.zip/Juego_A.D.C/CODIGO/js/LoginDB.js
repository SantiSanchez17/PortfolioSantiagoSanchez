window.indexedDB = window.indexedDB || window.mozIndexedDB ||
window.webkitIndexedDB || window.msIndexedDB

var txtClave;
var txtUsuario;
var bd;

function iniciar(){
	console.log ("Se inicia el programa");
	

	txtUsuario = document.getElementById("User");
	txtClave = document.getElementById("LogClave");

    btnLogin = document.getElementById("Login");

    btnLogin.addEventListener("click", VerificarLogin, false);

	var solicitud = indexedDB.open("baseA.D.C");
	solicitud.onsuccess = function (e){
		bd = e.target.result;
		//alert("La base de datos se abrió con éxito");
	}
}

function VerificarLogin(){
	var bUsuario = txtUsuario.value;
	var transaccion = bd.transaction(["Usuarios"], "readwrite");
	var almacen = transaccion.objectStore("Usuarios");
	var index = almacen.index("Usuario");
	var request = index.openCursor(bUsuario);
	request.onsuccess = function (e){
		var cursor = e.target.result;
		if (cursor) {
			var SisUsuario = cursor.value.Usuario;
			var SisClave = cursor.value.Clave;
		}
		if (SisUsuario == txtUsuario.value && SisClave == txtClave.value){
			alert("Login CORRECTO . . . Vamos al Menu de Inicio");
			window.open("Menu.html", "_Top");
			
		}else{
			alert("Login INCORRECTO...!!!");
		}
	}
}


window.addEventListener("load", iniciar, false);