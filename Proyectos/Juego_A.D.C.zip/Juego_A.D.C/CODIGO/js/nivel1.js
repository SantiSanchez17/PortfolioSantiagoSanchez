var lewis;
var resultado;
var x;
var cuenta=0;
var incorrecto;
var correcto;
var encontro;
var elemento;
var elemento_repuesta;
var id;
var encontro;
var src;
var solucion;
var consola;
function iniciar1(){
	lewis=document.getElementById("lewis");
	guia=document.getElementById("pregunta");
	salir=document.getElementById("x");
	guia.addEventListener("click",()=>{
		window.open("Guia.html","_Target");
	},false);
	salir.addEventListener("click",()=>{
		window.open("Menu.html","_Top");
	},false);

	function aleatorio(min,max) {
		var resultado;
		resultado=Math.floor(Math.random()*((max-min)+1)+min);
		return resultado;
	}
	function generador2(){
		x=aleatorio(1,6);
		document.getElementById('res').innerHTML="<img src='img/pool_nivel1/quimico"+x+".png'style=width:290px;height:240px;>";
		console.log(x);
		if (x==1) {
			solucion = [34,00,00];
		};
		if (x==2) {
			solucion = [24,00,00];
		};
		if (x==3) {
			solucion = [24,00,00];
		};
		if (x==4) {
			solucion = [14,00,00];
		};
		if (x==5) {
			solucion = [14,00,00];
		};
		if (x==6) {
			solucion = [24,00,00];
		};
	}
	generador2();

	function soluciones(){
		document.getElementById("1").src="img/respuestas/r1"+x+".png";
		document.getElementById("2").src="img/respuestas/r2"+x+".png";
		document.getElementById("3").src="img/respuestas/r3"+x+".png";
		console.log(x);
	}
	soluciones();

	function ocultarV(){
		incorrecto=document.getElementById("incorrecto").style.display="none";
		correcto=document.getElementById("correcto").style.display="none";
		generador2();
		soluciones();
		elemento_repuesta.innerHTML = "";
		cuenta=cuenta+1;
		if (cuenta==3) {
			window.open("Nivel2.html","_Top");
			cuenta=0;
		};
	}
	function ocultarD(){
		incorrecto=document.getElementById("incorrecto").style.display="none";
		generador2();
		soluciones();
		elemento_repuesta.innerHTML = "";

	}
	function mostrarD(){
		incorrecto=document.getElementById("incorrecto").style.display="block";
	}
	function mostrarV(){
		correcto=document.getElementById("correcto").style.display="block";
	}
	function Arrastre3(){
		//Creamos un ARRAY para guardar la solución
		//de pregunta-respuesta
		if (x==1) {
			solucion = [34,00,00];
		};
		if (x==2) {
			solucion = [24,00,00];
		};
		if (x==3) {
			solucion = [24,00,00];
		};
		if (x==4) {
			solucion = [14,00,00];
		};
		if (x==5) {
			solucion = [14,00,00];
		};
		if (x==6) {
			solucion = [24,00,00];
		};
		
		
		consola = document.getElementById("consola");
		//Seleccionamos todos los objetos img que están en 
		//el contenedor con el id="cajaimagenes" y los colocamos en un
		//ARRAY que llamaremos "imagenes" (Preguntas)
		var imagenes = document.querySelectorAll("#cajaimagenes img");
		//Colocamos a la escucha las imagenes de ORIGEN
		for (var i=0; i<imagenes.length; i++){
			imagenes[i].addEventListener("dragstart", inicia_arrastre, false);
			imagenes[i].addEventListener("dragend", terminado, false);
		}
		//Seleccionamos los objetos DESTINO que están en el
		//contenedor con id="respuestas" (Respuestas)
		var respuestas = document.querySelectorAll("#destino section");
		//Colocamos a la escucha los objetos de DESTINO (Objetos de Respuesta)
		for (var i=0; i<respuestas.length; i++){
			respuestas[i].addEventListener("dragenter", function (e) {
				e.preventDefault();},false);
			respuestas[i].addEventListener("dragover", entrando, false);
			respuestas[i].addEventListener("drop", soltado, false);
			respuestas[i].addEventListener("dragleave", saliendo, false);
		}
	
		function inicia_arrastre (e){
			//alert("Se inició el Arrastre");
			//Debemos identificar cuál objeto desencadenó la acción
			elemento = e.target;
			id =e.target.id;
			src = elemento.src;
			consola.innerHTML = " ";
			seleccionarElemento(e);
		}

		function terminado (e){
			//Debemos identificar cuál objeto desencadenó la acción
			elemento = e.target;
			if (encontro == 1){
				//elemento.style.visibility = "hidden";
			}else{
				elemento_respuesta.style.background = "#FFFFFF";
			}
			seleccionarElemento(e);
		}

		function entrando (e){
			//alert("Entrando");
			e.preventDefault();
			elemento_repuesta = e.target;
			id_repuesta = elemento_repuesta.id;
			consola.innerHTML = " ";
			//Buscamos si la respuesta es correcta:
			//Verificando si la pareja pregunta+respuesta
			//está en el Array ---> Solucion
			var buscar = id + id_repuesta;
			encontro = 0;
			for (var i=0; i<solucion.length; i++){
				if (buscar == solucion[i]){
				 	encontro=encontro+1;//Se encontro la respuesta correcta
				}
				if (encontro == 1){
					consola.innerHTML = " "
				}else{
					consola.innerHTML = " "
				}
			}
		}

		function soltado (e){
			e.preventDefault();
			elemento_repuesta = e.target;
			if (encontro == 1){
				//Asignamos y colocamos la imagen en la 
				//zona DESTINO
				elemento_repuesta.innerHTML = "<img src='" + src + "'/>";
				mostrarV();
				setTimeout(ocultarV,2000);
			}else{
				mostrarD();
				setTimeout(ocultarD,2000);
				elemento_repuesta.innerHTML = "<img src='" + src + "'/>";
			}
		}

		function saliendo(e) {
			//Si queremos que no haga nada el navegador
			//(resetear) el comportamiento por defecto
			e.preventDefault();
			elemento_repuesta = e.target;
			elemento_repuesta.style.background = "#FFFFFF";
			elemento_repuesta.innerHTML = "";
		}
		//*************************************************************
		//Definimos las variables para la información del moviento
		var elementSelect = 0;
		var currentX = 0;
		var currentY = 0;
		var currentPosX = 0;
		var currentPosY = 0;

		function seleccionarElemento (evt){
			//Guardamos el elemento seleccionado
			currentX = evt.clientX;
			currentY = evt.clientY;
			consola.innerHTML = "";
			//Obtenemos las coordenadas de la pieza a mover
			currentPosX = parseFloat(elementSelect.getAttribute("x"));
			currentPosY = parseFloat(elementSelect.getAttribute("y"));
			//Agregamos el evento del movimiento a la imagen seleccionada
			elementSelect.setAttribute("onmousemove", "moverElemento(evt)");
		}

		function moverElemento(evt) {
			consola.innerHTML += " MOVER ELEMENTO";
			var dx = evt.clientX - currentX;
			var dy = evt.clientY - currentY;
			//Para que el elemento se mueva actualizamos
			//y asignamos la nueva posición
			currentPosX = currentPosX + dx;
			currentPosY = currentPosY + dy;
			//Volvemos a guardar la posición del mouse
			currentX = evt.clientX;
			currentY = evt.clientY;
			//Al soltar el click del mouse debemos soltar
			//la imagen elegida
			elementSelect.setAttribute("onmouseout", "deseleccionarElemento(evt)");
			elementSelect.setAttribute("onmouseup", "deseleccionarElemento(evt)");
		}
	}
	Arrastre3();
}
window.addEventListener("load",iniciar1,false);