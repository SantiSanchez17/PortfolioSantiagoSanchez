
function iniciar(){
	console.log ("Se inicia el programa");
	
	btnGuia = document.getElementById ("Guia");
	btnPlay = document.getElementById ("Play");
	btnCreditos = document.getElementById ("Creditos");

	btnGuia.addEventListener("click", Guia, false);
	btnPlay.addEventListener("click", Play, false);
	btnCreditos.addEventListener("click", Creditos, false);
}
function Guia(){
	console.log ("Presionaste el botón Guia");
	window.open("Guia.html", "_Top");
}
function Play(){
	console.log ("Presionaste el botón de Play");
	window.open("Nivel1.html", "_Top");
}
function Creditos(){
	console.log ("Presionaste el botón Creditos");
	window.open("Creditos.html", "_Top");
}

window.addEventListener("load", iniciar, false);