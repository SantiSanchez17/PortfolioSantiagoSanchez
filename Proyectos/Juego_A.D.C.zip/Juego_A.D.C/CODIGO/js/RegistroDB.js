//Javascript Document
window.indexedDb = window.indexedDb || window.mozIndexedDB ||
window.webkitIndexedDB || window.msIndexedDB
var bd;
var bd;
var zonadatos;
var cursor;
var cuenta = 0;
function iniciar(){
	alert("Hola");
	console.log ("Se inicia el programa");
	
	//Defino elementos de la página
	txtNombre = document.getElementById("Nombre");
	txtApellido = document.getElementById("Apellido");
	txtUsuario = document.getElementById("Usuario");
	txtClave = document.getElementById("Contrasena");
	btnAtrás = document.getElementById("Atras");
	btnSiguiente = document.getElementById("Siguiente");
	btnVerUsuarios = document.getElementById("VerUsuarios");
	btnRegistrar = document.getElementById("Registrar");
	btnBuscar = document.getElementById("Buscar");
	btnActualizar = document.getElementById("Actualizar");
	btnEliminar = document.getElementById("Eliminar");
	zonadatos = document.getElementById("zonadatos");

	btnVerUsuarios.addEventListener("click", VerUsuarios, false);
	btnRegistrar.addEventListener("click", Registrar, false);
	btnBuscar.addEventListener("click", Buscar, false);
	btnActualizar.addEventListener("click", Actualizar, false);
	btnEliminar.addEventListener("click", Eliminar, false);
	btnAtrás.addEventListener("click", Atras, false);
	btnSiguiente.addEventListener("click", Siguiente, false);

	var solicitud = indexedDB.open("baseA.D.C");

	solicitud.onsuccess = function(e){
		bd = e.target.result;
		//alert("La base de datos se conecto con exito")
	}
	solicitud.onupgradeneeded = function(e){
		bd = e.target.result;
		bd.createObjectStore("gente", {keyPath: "Clave"});
		var tbUsuario = bd.createObjectStore("Usuarios", {keyPath: "Apellido"});
		tbUsuario.createIndex("Nombre", "Nombre", {unique: false});
		tbUsuario.createIndex("Usuario", "Usuario", {unique: false});
	}
}

function VerUsuarios(){
	console.log ("Presionaste el botón Ver Usuarios");
	cuenta = 0;
	zonadatos.innerHTML = ""; 
	var transaccion = bd.transaction(["Usuarios"], "readonly");
	var almacen = transaccion.objectStore("Usuarios");
	cursor = almacen.openCursor();
	cursor.addEventListener("success", mostrarDatosUsuarios, false);
}
function mostrarDatosUsuarios(e){
	//alert("Mostrar Datos Usuarios");
	var cursor = e.target.result;

	if (cursor){
		zonadatos.innerHTML += "<div>" + cuenta + "-->" + cursor.value.Apellido +
		"-" + cursor.value.Nombre + "-" + cursor.value.Usuario + "</div>";

		cursor.continue();
		cuenta = cuenta + 1;
	}
	if (cuenta == 0){
		alert("Datos no encontrados")
	}
}

function Registrar(){
	console.log ("Presionaste el botón de Registrar");
	var Apellido = document.getElementById("Apellido").value;
	var Nombre = document.getElementById("Nombre").value;
	var Usuario = document.getElementById("Usuario").value;
	var Clave = document.getElementById("Contrasena").value;
	var transaccion = bd.transaction(["Usuarios"], "readwrite");
	var almacen = transaccion.objectStore("Usuarios");
	var agregar = almacen.add({Apellido: Apellido, Nombre: Nombre,
	 Usuario: Usuario, Clave: Clave});
	alert("El registro se realizó con éxito")
	Limpiar();
}
function Limpiar(){
	document.getElementById("Nombre").value="";
	document.getElementById("Apellido").value="";
	document.getElementById("Usuario").value="";
	document.getElementById("Contrasena").value="";
}

function Buscar(){
	console.log ("Presionaste el botón Ver Buscar");
	zonadatos.innerHTML = "";
	if (document.getElementById("Apellido").value !== ""){
		BuscarApellido();
	}
	if (document.getElementById("Nombre").value !== ""){
		BuscarNombre();
	}
}

function BuscarApellido(){
	alert("Buscando Apellido");
	cuenta = 0;
	var transaccion = bd.transaction(["Usuarios"], "readonly");
	var almacen = transaccion.objectStore("Usuarios");
	var buscaras = txtApellido.value;
	var ver = IDBKeyRange.only(buscaras);
	var cursor = almacen.openCursor(ver, "next");
	cursor.addEventListener("success", mostrarDatosUsuarios, false);
}

function BuscarNombre(){
	alert("Buscar Nombre");
	cuenta = 0;
	var bNombre = txtNombre.value;
	var transaccion = bd.transaction(["Usuarios"], "readwrite");
	var almacen = transaccion.objectStore("Usuarios");
	var index = almacen.index("Nombre");
	var cursor = index.openCursor(bNombre);
	cursor.addEventListener("success", mostrarDatosUsuarios, false);
}

function Actualizar(){
	console.log ("Presionaste el botón Actualizar");

	var Nombre = document.getElementById("Nombre").value = "";
	var Apellido = document.getElementById("Apellido").value = "";
	var Usuario = document.getElementById("Usuario").value = "";
	var Clave = document.getElementById("Contrasena").value = "";

	var transaccion = bd.transaction(["Usuarios"], "readwrite");
	var almacen = transaccion.objectStore("Usuarios");
	var request = almacen.put({Apellido: Apellido, Nombre: Nombre,
	 Usuario: Usuario, Clave: Clave});
	request.onsuccess = function(e) {
		alert("Se actualizo el registro");
	}
	request.onerror = function(e){
		alert("Ocurrio un error al actualizar")
	}
}
function Eliminar(){
	alert("Presionaste el botón Eliminar");
	var bApellido = txtApellido.value;
	var transaccion = bd.transaction(["Usuarios"], "readwrite");
	var almacen = transaccion.objectStore("Usuarios");
	var request = almacen.delete(bApellido);
	request.onsuccess = function (e){
		alert("Se elemino el registro");
	}
	request.onerror = function(e){
		alert("Ocurrio un error al borrar el registro");
	}

}
function Atras(){
	alert("Presionaste el botón atras");
}
function Siguiente(){
	alert("Presionaste el botón siguiente");
}

window.addEventListener("load", iniciar, false);
