//Javascript Document
function tiempo () {
	setTimeout(espera,5000);
}
function espera(){
	window.open("Creditos.html","_Top");
}



window.addEventListener("load",tiempo,false);