<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asistencia - Validar Login</title>
</head>
<body>
    <?php

        echo "Estamos en Validando Login";
        /*Traemos desde la pagina Login.php el valor 
        que el usuario ingresó en los campos*/
        print_r($_POST);
        $usuario = $_POST["usuario"];
        $clave = $_POST["clave"];
        echo "<br>Usuario: " . $usuario;
        echo "<br>Clave: " . $clave;

        //Datos para ubicar el servidor de BDD
        //Los traemos desde el archivo php
        require ("Datos_ConexionBDD.php");

        //Establecemos la conexion  con la base de datos
        //***** Primero con ek Host:
        $conexion=mysqli_connect($db_host, $db_usuario, $db_clave);
        
        //Verificamos si la Conexion con el Host tuvo éxito
        if (mysqli_connect_errno()){
            echo "Error al coneectar con la Base de Datos";
            exit(); //Salimos de la Conexion
        }
        //***** Segundo son la Base de datos 
        //Si no la encuentra nos informa el Error
        mysqli_select_db($conexion, $db_nombre) or die ("No se encuentra la BDD");
        //Confirmamos que vamos a usar caracteres latinos
        //Para fectos de las Tíldes 
        mysqli_set_charset ($conexion, "UTF8"); //UTF8 --> UTF8
        echo "<br>Nos conectamos al servidor y a la DDBB";
        //exit();

        /*Realizamos la consulta a la base de datos 
        tanto para el usuario, como para la clave*/
        $consulta = "SELECT * FROM registro WHERE usuario = '$usuario'";

        //Ejecuatamos la consulta y la guardamos en un resultado
        $resultados = mysqli_query($conexion, $consulta); 

        $Registros = 0;
        //Utilizando  ARRAY ASOCIATIVO --> MYSQLI_SSOC --> Usamos el NOMBRE DEL CAMPO
        //                                 MYSQL_BOTH  --> Usamos tato el INDICE como el NOMBRE  del CAMPO

        while ($fila = mysqli_fetch_array($resultados, MYSQLI_BOTH)){ 
            // Se asume como si fuera --> == true 
            echo "<br>Clave en BD = " . $fila['clave'];
            if ($clave == $fila ['clave']){
                echo "<br>Datos Correctos . . . continue";
                header ("Location:../Mapa.php");
            }else{
                echo "Datos INCORRECTOS . . .!!!";
            }
            $Registros ++;
        }

        echo "<br>Registros: " . $Registros;

        if ($Registros == 0){
            echo "<br>No hay nada de registros";
            header ("Location:Login.php");
        }

    ?>
</body>
</html>