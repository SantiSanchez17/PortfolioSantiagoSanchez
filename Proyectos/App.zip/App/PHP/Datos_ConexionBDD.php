<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        /*DATOS REQUERIDOS PARA LA CONEXION DE UNA BASE DE DATOS 
        1. DIRECCIONDE LA BASE DE DATOS
        2. NOMBRE DE LA BASE DE DATOS 
        3. USUARIO
        4. CONTRASEÑA*/

        //LOCAL
        $db_host = "localhost";
        $db_nombre = "electrifind";
        $db_usuario = "root";
        $db_clave = "";


        /* 
        //SERVER
        $db_host = "localhost";
        $db_nombre = "tecnjhbk_HAG";
        $db_usuario = "tecnjhbk_luemonar";
        */
    ?>
</body>
</html>