<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        echo "Estoy en guardar asistencia";
        print_r($_REQUEST);
        $Respuestas = count($_REQUEST);
        echo $Respuestas;
        $nombre = $_POST['nombre'];
        $celular = $_POST['celular'];
        $usuario = $_POST['usuario'];
        $clave = $_POST['clave'];

        $Registro = array($nombre, $celular, $usuario, $clave);
        $Buscar = "";
        $resultSearch = in_array($Buscar, $Registro);
        $PosicionSearch = array_search($Buscar, $Registro);

        if ($resultSearch){
            echo "<script type=\"text/javascript\">
            alert('Faltan Datos por completar en el formulario');
            history.back();
            </script>";
            exit();
        }
        echo "<br>DATOS COMPLETOS";

        require("Datos_ConexionBDD.php");
        $conexion=mysqli_connect($db_host, $db_usuario, $db_clave);

        if (mysqli_connect_errno()){
            echo "Error al coneectar con la Base de Datos";
            exit(); //Salimos de la Conexion
        }

        mysqli_select_db($conexion, $db_nombre) or die ("No se encuentra la BDD");
        //Confirmamos que vamos a usar caracteres latinos
        //Para fectos de las Tíldes 
        mysqli_set_charset ($conexion, "UTF8");

        $consulta = "INSERT INTO registro (NOMBRE, CELULAR, USUARIO, CLAVE)
        VALUES ('$nombre', '$celular', '$usuario', '$clave')";
        //echo $consulta;

        $resultados = mysqli_query($conexion, $consulta);

        if ($resultados == false){
            echo "Error en la consulta";
        }else{
            header ("Location:../Mapa.php");
        }
    ?>
</body>
</html>