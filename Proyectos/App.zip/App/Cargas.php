<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cargas</title>
    <link rel="icon" href="img/Logos (1).png">
    <link rel="stylesheet" href="CSS/inicio.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
    <script src="Js/Charge.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
</head>

<body class="animate__animated animate__backInLeft">
    <div class="fondo">
        <div class="container">
            <img src="img/Logos (1).png" alt="">
            <form action="" class="container__form">
                <input type="button" value="Carga Lenta" onclick="CL()">
                <input type="button" value="Carga Rapida" onclick="CR()">
            </form>
        </div>
    </div>
</body>

</html>