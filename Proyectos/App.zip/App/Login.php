<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="icon" href="img/Logos (1).png">
    <link rel="stylesheet" href="CSS/Login.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
</head>

<body class="animate__animated animate__backInLeft">
    <div class="fondo">
        <div class="container">
            <img src="img/Logos (1).png" alt="Logo">
            <form action="PHP/ValidLogin.php" class="container__form" method="post" name="Login" id="Login">
                <input type="text" name="usuario" id="usuario" placeholder="Usuario">
                <input type="password" name="clave" id="clave" placeholder="Contraseña">

                <input type="submit" id="buscar" name="enviando" value="Entrar">

                <span class="container__form-span">¿No tienes cuenta?<a href="Registro.php">Crear cuenta</a></span>
                <!--<span class="container__form-span"><a href="">¿Haz olvidado tu contraseña?</a></span>-->
            </form>
        </div>
    </div>
</body>

</html>