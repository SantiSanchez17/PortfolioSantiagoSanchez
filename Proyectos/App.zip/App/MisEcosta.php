<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Ecoestaciones</title>
    <link rel="icon" href="img/Logos (1).png">
    <link rel="stylesheet" type="text/css" href="CSS/MisEcoestaciones.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
        crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"
        integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF"
        crossorigin="anonymous"></script>
</head>

<body class="animate__animated animate__backInLeft">
    <h1>Mis Ecoestaciones</h1>
    <br>
    <div class="cuadro">
        <img id="icon" src="img/Icono.png" alt="" >
    </div>
    <div class="cuadro">
        <select name="lugar" id="lugar" onchange="GSV()">
            <option value="">
                Selecciona la eccoestación
            </option>
            <!--<option value="EPM Aeropuerto">
                EPM Aeropuerto Km 1 Glorieta Aeropuerto José María Córdova
            </option>
            <option value="EPM Aguacatala">
                EPM Aguacatala Calle 50E #10 sur - 130
            </option>
            <option value="EPM Av. Oriental">
                EPM Av. Oriental Calle 41 # 46 – 29
            </option>
            <option value="EPM Belén">
                EPM Belén Calle 30A # 69C – 11
            </option>
            <option value="EPM Bolivariana">
                EPM Bolivariana Calle 33 # 66A -21
            </option>
            <option value="EPM Castilla">
                EPM Castilla Transversal 78 # 65 – 71
            </option>
            <option value="EPM Caribe">
                EPM Caribe Carrera 64C # 72-226
            </option>
            <option value="EPM Exposiciones">
                EPM Exposiciones Calle 36 # 53-55
            </option>
            <option value="EPM El Bosque">
                EPM El Bosque Carrera 52 # 78 - 20
            </option>-->
            <option value="EPM Florida" id="Florida">
                EPM C.C Florida Cll 71 #65 - 150.
            </option>
            <!--<option value="EPM Itagüí">
                EPM Itagüí Carrera 52 # 60 – 110
            </option>-->
            <option value="EPM Laureles" id="Laureles">
                EPM Laureles
            </option>
            <!--<option value="EPM La 30">
                EPM La 30 Carrera 65 # 30 – 40
            </option>-->
            <option value="EPM Las Vegas" id="Vegas">
                EPM Las Vegas Calle 57 sur # 48 – 25
            </option>
            <option value="EPM Mayorca" id="Mayorca">
                EPM Mayorca Carrera 48 # 30 sur - 48
            </option>
            <option value="EPM Molinos" id="Molinos">
                EPM C.C Los Molinos Cll. 30A ##82A - 26
            </option>
            <option value="EPM Nutibara" id="Nutibara">
                EPM Nutibara Transversal 39B #79 - 41
            </option>
            <option value="EPM Plaza" id="Plaza">
                EPM C.C Plaza Mayor Calle 41 # 55-80
            </option>
            <!--<option value="EPM Punto Cero" id="Punto">
                EPM Punto Cero Diagonal 64E # 67-405
            </option>-->
            <option value="EPM Sabaneta" id="Sabaneta">
                EPM Sabaneta Cra 48 entre las Calles 72 y 73 Sur
            </option>
            <option value="EPM SantaFe" id="SantaFe">
                EPM C.C Santa Fé Carrera 43a #7 Sur - 170
            </option>
            <option value="EPM Saopaulo" id="Saopaulo">
                EPM C.C Sao Paulo  Avenida El Poblado No. 18Sur - 135
            </option>
            <option value="EPM Tesoro" id="Tesoro">
                EPM C.C El Tesoro Transversal Superior Carrera 25A # 1A Sur - 45
            </option>
            <option value="EPM Unicentro" id="Unicentro">
                EPM C.C Unicentro Cra. 66B #34A - 76
            </option>
        </select>
    </div>
    <br>
    <div class="cuadro">
        <select name="conector" id="tipos" onchange="filter()">
            <option value="Todo">Mostrar Todo</option>
            <option value="AC">AC</option>
            <option value="DC">DC</option>
            <option value="Doble">Doble Conector</option>
        </select>
    </div>
    <br>
    <div class="cuadro" id="carrul">
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active" id="Foto_1">
                </div>
                <div class="carousel-item" id="Foto_2">
                </div>
                <div class="carousel-item" id="Foto_3">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev" id="colorB">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next" id="colorB">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>

    <br><br>
    <div class="Buton">
        <input type="button" value="VOLVER" onclick="Cancel()">
    </div>
    <br><br>
</body>
<script src="Js/MisEco.js"></script>

</html>