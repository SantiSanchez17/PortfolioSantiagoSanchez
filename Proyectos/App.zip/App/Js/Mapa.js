
Carro = document.getElementById('Carro');
Star = document.getElementById('star1');
Star2 = document.getElementById('star2');
Star3 = document.getElementById('star3');
Star4 = document.getElementById('star4');
Star5 = document.getElementById('star5');
estacion = document.getElementById('ecosta');
mapear = document.getElementById('rut');

Star.addEventListener("click", () => {
    Carro.innerHTML = "<input type=button' id='star1'> <label for='star1' class='fas fa-star'></label> <input type=button' id='star2'> <label for='star2' class='far fa-star'></label> <input type=button' id='star3'> <label for='star3' class='far fa-star'></label> <input type=button' id='star4'> <label for='star4' class='far fa-star'></label> <input type=button' id='star5'> <label for='star5' class='far fa-star'></label>";
}, false);


Star2.addEventListener("click", () => {
    Carro.innerHTML = "<input type=button' id='star1'> <label for='star1' class='fas fa-star'></label> <input type=button' id='star2'> <label for='star2' class='fas fa-star'></label> <input type=button' id='star3'> <label for='star3' class='far fa-star'></label> <input type=button' id='star4'> <label for='star4' class='far fa-star'></label> <input type=button' id='star5'> <label for='star5' class='far fa-star'></label>";
}, false);


Star3.addEventListener("click", () => {
    Carro.innerHTML = "<input type=button' id='star1'> <label for='star1' class='fas fa-star'></label> <input type=button' id='star2'> <label for='star2' class='fas fa-star'></label> <input type=button' id='star3'> <label for='star3' class='fas fa-star'></label> <input type=button' id='star4'> <label for='star4' class='far fa-star'></label> <input type=button' id='star5'> <label for='star5' class='far fa-star'></label>";
}, false);


Star4.addEventListener("click", () => {
    Carro.innerHTML = "<input type=button' id='star1'> <label for='star1' class='fas fa-star'></label> <input type=button' id='star2'> <label for='star2' class='fas fa-star'></label> <input type=button' id='star3'> <label for='star3' class='fas fa-star'></label> <input type=button' id='star4'> <label for='star4' class='fas fa-star'></label> <input type=button' id='star5'> <label for='star5' class='far fa-star'></label>";
}, false);

Star5.addEventListener("click", () => {
    Carro.innerHTML = "<input type=button' id='star1'> <label for='star1' class='fas fa-star'></label> <input type=button' id='star2'> <label for='star2' class='fas fa-star'></label> <input type=button' id='star3'> <label for='star3' class='fas fa-star'></label> <input type=button' id='star4'> <label for='star4' class='fas fa-star'></label> <input type=button' id='star5'> <label for='star5' class='fas fa-star'></label>";
}, false);

function GSV(){
    var selectValue = document.getElementById("rutas").value;

    if (selectValue == "EPM Aguacatala"){
        Agua();
    }

    if (selectValue == "EPM Av. Oriental"){
        Orien();
    }

    if (selectValue == "EPM Belén"){
        Belen();
    }

    if (selectValue == "EPM Castilla"){
        Cast();
    }

    if (selectValue == "EPM Exposiciones"){
        Expos();
    }

    if (selectValue == "EPM Punto Cero"){
        Cero();
    }

    if (selectValue == "EPM El Bosque"){
        Bosque();
    }

    if (selectValue == "EPM Bolivariana"){
        Boliv();
    }

    if (selectValue == "EPM Caribe"){
        Caribe();
    }

    if (selectValue == "EPM Itagüí"){
        Itagui();
    }

    if (selectValue == "EPM Las Vegas"){
        Envigado();
    }

    if (selectValue == "EPM Mayorca"){
        Mayorca();
    }

    if (selectValue == "EPM Aeropuerto"){
        Aero();
    }

    if (selectValue == "EPM Florida"){
        Florida();
    }

    if (selectValue == "EPM Laureles"){
        Laureles();
    }

    if (selectValue == "EPM Molinos"){
        Molinos();
    }

    if (selectValue == "EPM Nutibara"){
        Nutibara();
    }

    if (selectValue == "EPM Plaza"){
        Plaza();
    }

    if (selectValue == "EPM Sabaneta"){
        Sabaneta();
    }

    if (selectValue == "EPM SantaFe"){
        SantaFe();
    }

    if (selectValue == "EPM Saopaulo"){
        Saopaulo();
    }

    if (selectValue == "EPM Tesoro"){
        Tesoro();
    }

    if (selectValue == "EPM Unicentro"){
        Unicentro();
    }
}

function Envigado(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.791536739767!2d-75.60890139317476!3d6.158668168770411!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e4683d02bab1209%3A0x47348cc3d4f59809!2sCl.%2057%20Sur%20%2348-25%2C%20Sabaneta%2C%20Antioquia!5e0!3m2!1ses!2sco!4v1633391624991!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Las Vegas";
}

function Florida(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.9466726600695!2d-75.57918908603283!3d6.270743595461244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e468290801fc40b%3A0x278d1d049676680b!2sFlorida%20Parque%20Comercial!5e0!3m2!1ses!2sco!4v1633528695616!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Florida";
}

function Laureles(){
    mapear.innerHTML = "Ecoestacion:";
}

function Mayorca(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.767965626226!2d-75.60770398573439!3d6.1618225289728334!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e4683cc2769fda9%3A0x997386a695af1002!2sCentro%20Comercial%20Mayorca%20Mega%20Plaza!5e0!3m2!1ses!2sco!4v1633530967243!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Mayorca";
}

function Molinos(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7932.477077214156!2d-75.6083910651123!3d6.232253099999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e442993eeb42edd%3A0x75818b7e73dfbd5e!2sCentro%20Comercial%20Los%20Molinos!5e0!3m2!1ses!2sco!4v1633906277514!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Los Molinos";
}

function Nutibara(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15864.96374272415!2d-75.604322!3d6.231936!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x674674e82cade485!2sEcoestacion%20Electrica%20EPM!5e0!3m2!1ses!2sco!4v1633909074383!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Nutibara";
}

function Plaza(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.1508261082986!2d-75.57808868573416!3d6.243845228084603!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e4429ab627545c1%3A0x23674fd4c47ec19c!2sCentro%20de%20Convenciones%20Plaza%20Mayor!5e0!3m2!1ses!2sco!4v1633531120890!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Plaza Mayor";
}

function Sabaneta(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15867.384524180288!2d-75.62643463022462!3d6.151356000000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e4683ded6f2c369%3A0x224b8881cd046e3c!2sAtenci%C3%B3n%20Epm%20Sabaneta!5e0!3m2!1ses!2sco!4v1633531425155!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Sabaneta";
}

function SantaFe(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.5081218472365!2d-75.57601898573424!3d6.19648962859873!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e4682881ca00127%3A0xf96762aa39ea4209!2sCentro%20Comercial%20Santaf%C3%A9!5e0!3m2!1ses!2sco!4v1633531492693!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Santa Fé";
}

function Saopaulo(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.596720082768!2d-75.58156488573425!3d6.184691028726282!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e46825e8765ee77%3A0xaae8e48874931f61!2sSao%20Paulo%20Plaza!5e0!3m2!1ses!2sco!4v1633531596575!5m2!1ses!2sco' width='600' height='45' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Sao Paulo";
}

function Tesoro(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.507672689439!2d-75.56107028592633!3d6.196549385794312!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e46829a65a5d1ab%3A0xacb563511f221ff3!2sEl%20Tesoro%20Parque%20Comercial!5e0!3m2!1ses!2sco!4v1633531708879!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: El Tesoro";
}

function Unicentro(){
    mapear.innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.1717071196576!2d-75.58958118573416!3d6.241087528114612!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e4429a573d090a7%3A0x426cf6249a68c3a6!2sCentro%20Comercial%20Unicentro%20Medell%C3%ADn!5e0!3m2!1ses!2sco!4v1633531767281!5m2!1ses!2sco' width='100%' height='736px' style='border:0;' allowfullscreen='' loading='lazy'></iframe>";
    estacion.innerHTML = "Ecoestacion: Unicentro";
}