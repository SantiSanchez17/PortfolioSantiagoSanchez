
function Rep() {
    alert("¡Se ha reportado exitosamente!");
    window.open("Mapa.php", "_Top");
}

function Cancel() {
    window.open("Mapa.php", "_Top");
}
