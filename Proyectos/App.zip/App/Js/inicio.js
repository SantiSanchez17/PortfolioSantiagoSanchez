

function Log() {
    window.open("Login.php", "_Top");
}

function Reg() {
    window.open("Registro.php", "_Top");
}

function acerca() {
    window.open("ADN.html", "_Target");
}