foto1 = document.getElementById('Foto_1');
foto2 = document.getElementById('Foto_2');
foto3 = document.getElementById('Foto_3');
carrul = document.getElementById("carrul");
florida = document.getElementById("Florida");
laureles = document.getElementById("Laureles");
vegas = document.getElementById("Vegas");
mayorca = document.getElementById("Mayorca");
molinos = document.getElementById("Molinos");
nutibara = document.getElementById("Nutibara");
plaza = document.getElementById("Plaza");
sabaneta = document.getElementById("Sabaneta");
santa = document.getElementById("SantaFe");
saopaulo = document.getElementById("Saopaulo");
tesoro = document.getElementById("Tesoro");
uni = document.getElementById("Unicentro");

var x = 1;

function GSV(){
    var selectValue = document.getElementById("lugar").value;

    if (selectValue == "EPM Aguacatala"){
        Agua();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Av. Oriental"){
        Orien();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Belén"){
        Belen();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Castilla"){
        Cast();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Exposiciones"){
        Expos();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Punto Cero"){
        Cero();
        carrul.style.display="block";
    }

    if (selectValue == "EPM El Bosque"){
        Bosque();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Bolivariana"){
        Boliv();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Caribe"){
        Caribe();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Itagüí"){
        Itagui();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Las Vegas"){
        Envigado();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Mayorca"){
        Mayorca();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Aeropuerto"){
        Aero();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Florida"){
        Florida();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Laureles"){
        Laureles();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Molinos"){
        Molinos();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Nutibara"){
        Nutibara();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Plaza"){
        Plaza();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Sabaneta"){
        Sabaneta();
        carrul.style.display="block";
    }

    if (selectValue == "EPM SantaFe"){
        SantaFe();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Saopaulo"){
        Saopaulo();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Tesoro"){
        Tesoro();
        carrul.style.display="block";
    }

    if (selectValue == "EPM Unicentro"){
        Unicentro();
        carrul.style.display="block";
    }
}

function filter(){
    var SectVal = document.getElementById("tipos").value;

    if(SectVal == "Todo"){
        florida.style.display = "block";
        laureles.style.display = "block";
        vegas.style.display = "block";
        saopaulo.style.display = "block";

        mayorca.style.display = "block";
        molinos.style.display = "block";
        nutibara.style.display = "block";
        tesoro.style.display = "block";

        plaza.style.display = "block";
        sabaneta.style.display = "block";
        santa.style.display = "block";
        uni.style.display = "block";
    }

    if(SectVal == "AC"){
        florida.style.display = "block";
        laureles.style.display = "block";
        vegas.style.display = "block";
        saopaulo.style.display = "block";

        mayorca.style.display = "none";
        molinos.style.display = "none";
        nutibara.style.display = "none";
        tesoro.style.display = "none";

        plaza.style.display = "block";
        sabaneta.style.display = "block";
        santa.style.display = "block";
        uni.style.display = "block";
    }

    if(SectVal == "DC"){
        florida.style.display = "none";
        laureles.style.display = "none";
        vegas.style.display = "none";
        saopaulo.style.display = "none";

        mayorca.style.display = "block";
        molinos.style.display = "block";
        nutibara.style.display = "block";
        tesoro.style.display = "block";

        plaza.style.display = "block";
        sabaneta.style.display = "block";
        santa.style.display = "block";
        uni.style.display = "block";
    }

    if(SectVal == "Doble"){
        florida.style.display = "none";
        laureles.style.display = "none";
        vegas.style.display = "none";
        saopaulo.style.display = "none";

        mayorca.style.display = "none";
        molinos.style.display = "none";
        nutibara.style.display = "none";
        tesoro.style.display = "none";

        plaza.style.display = "block";
        sabaneta.style.display = "block";
        santa.style.display = "block";
        uni.style.display = "block";
    }
}

function Envigado(){
    foto1.innerHTML="<img src='img/ENVIGADO.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/ConectAC.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/AC.jpg' alt='' style='height: 200px;'>";
}

function Florida(){
    foto1.innerHTML="<img src='img/FLORIDA.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/ConectAC.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/AC.jpg' alt='' style='height: 200px;'>";
}

function Laureles(){
    foto1.innerHTML="<img src='img/LAURELES.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/ConectAC.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/AC.jpg' alt='' style='height: 200px;'>";
}

function Mayorca(){
    foto1.innerHTML="<img src='img/MAYORCA.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/ConectDC.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/DC.jpg' alt='' style='height: 200px;'>";
}

function Molinos(){
    foto1.innerHTML="<img src='img/MOLINOS.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/ConectDC.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/DC.jpg' alt='' style='height: 200px;'>";
    
}

function Nutibara(){
    foto1.innerHTML="<img src='img/NUTIBARA.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/ConectDC.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/DC.jpg' alt='' style='height: 200px;'>";
}

function Plaza(){
    foto1.innerHTML="<img src='img/PLAZA.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/DosConect.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/DConect.png' alt='' style='height: 200px;'>";
}

function Sabaneta(){
    foto1.innerHTML="<img src='img/SABANETA.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/DosConect.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/DConect.png' alt='' style='height: 200px;'>";
}

function SantaFe(){
    foto1.innerHTML="<img src='img/SANTAFE.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/DosConect.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/DConect.png' alt='' style='height: 200px;'>";
}

function Saopaulo(){
    foto1.innerHTML="<img src='img/SAOPAULO.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/ConectAC.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/AC.jpg' alt='' style='height: 200px;'>";
}

function Tesoro(){
    foto1.innerHTML="<img src='img/TESORO.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/ConectDC.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/DC.jpg' alt='' style='height: 200px;'>";
}

function Unicentro(){
    foto1.innerHTML="<img src='img/UNICENTRO.jpeg' alt='' style='height: 200px;'>";
    foto2.innerHTML="<img src='img/DosConect.png' alt='' style='height: 200px;'>";
    foto3.innerHTML="<img src='img/DConect.png' alt='' style='height: 200px;'>";
}

function Cancel() {
    window.open("Mapa.php", "_Top");
}