function CL() {
    window.open("CargaL.php", "_Top");
}

function CR() {
    window.open("CargaR.php", "_Top");
}