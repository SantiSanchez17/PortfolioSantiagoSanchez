<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reportes</title>
	<link rel="icon" href="img/Logos (1).png">
	<link rel="stylesheet" href="CSS/ResolverProblema.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
	<script src="Js/RP.js"></script>
</head>

<body class="animate__animated animate__backInLeft">
	<h1> REPORTE DE DAÑOS </h1>
	<br>
	<div class="container">
		<img src="img/Icono.png" alt="">
		<form action="PHP/Reportes_Datos.php" method="post" class="container__form">
			<h2 id="Cel">Dirección</h2>
			<select name="lugar" id="lugar">
                <option value="EPM Aguacatala">
                	EPM Aguacatala Calle 50E #10 sur - 130
                </option>
                <option value="EPM Av. Oriental">
                    EPM Av. Oriental Calle 41 # 46 – 29
                </option>
                <option value="EPM Belén">
                    EPM Belén Calle 30A # 69C – 11
                </option>
                <option value="EPM Castilla">
                    EPM Castilla Transversal 78 # 65 – 71
                </option>
                <option value="EPM Exposiciones">
                    EPM Exposiciones Calle 36 # 53-55
                </option>
                <option value="EPM La 30">
                    EPM La 30 Carrera 65 # 30 – 40
                </option>
                <option value="EPM Punto Cero">
                    EPM Punto Cero Diagonal 64E # 67-405
                </option>
                <option value="EPM El Bosque">
                    EPM El Bosque Carrera 52 # 78 - 20
                </option>
                <option value="EPM Bolivariana">
                    EPM Bolivariana Calle 33 # 66A -21
                </option>   
                <option value="EPM Caribe">
                    EPM Caribe Carrera 64C # 72-226
                </option>
                <option value="EPM Itagüí">
                    EPM Itagüí Carrera 52 # 60 – 110
                </option>
                <option value="EPM Las Vegas">
                    EPM Las Vegas  Calle 57 sur # 48 – 25
                </option>
                <option value="EPM Mayorca">
                    EPM Mayorca Carrera 48 # 30 sur - 48
                </option> 
                <option value="EPM Aeropuerto">
                    EPM Aeropuerto Km 1 Glorieta Aeropuerto José María Córdova
                </option>                  
            </select>
            <br>
            <h2>Fecha</h2>
                <?php
                    ini_set('date.timezone','America/Bogota');
                    $Hora = date("g:i A");
                    $fechaActual = date('d/m/Y');
                    $fechaDate = date('Y-m-d');

                    echo"
                    <td>
                    <input type='date' name='fecha' 
                    value='" . $fechaDate ."' readonly>
                    </td>";
                ?>
			<br>
			<h2 style="margin-bottom: 7px;">Descripcion del problema</h2>
			<textarea name="reporte" id="reporte" cols="40" rows="5" 
			placeholder="Escriba las observaciones respecto a la estación" 
			maxlength="250"></textarea>
			<input type="submit" value="REPORTAR" id="buscar" onclick="Rep()">
            <input type="button" value="CANCELAR" onclick="Cancel()">
		</form>
	</div>
	<br>
</body>