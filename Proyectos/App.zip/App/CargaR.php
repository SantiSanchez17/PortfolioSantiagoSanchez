<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Temporizador</title>
    <link rel="icon" href="img/Logos (1).png">
    <link rel="stylesheet" href="CSS/TempoEstilo.css">

    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
</head>

<body>
    <div class="container">
        <img src="img/Logos (1).png" alt="Logo">
    </div>
    <div class="cont-temporizador">
        <div class="bloque">
            <div class="horas" id="horas">--</div>
            <p>HORAS</p>
        </div>
        <div class="bloque">
            <div class="minutos" id="minutos">--</div>
            <p>MINUTOS</p>
        </div>
        <div class="bloque">
            <div class="segundos" id="segundos">--</div>
            <p>SEGUNDOS</p>
        </div>
    </div>
    <br><br>
    <div class="container__form">
        <input type="button" value="VOLVER" onclick="Cancel()">
    </div>
</body>
<script src="Js/CargaR
.js"></script>

</html>