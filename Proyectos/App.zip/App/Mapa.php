<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mapa</title>
    <link rel="icon" href="img/Logos (1).png">
    <link rel="stylesheet" href="CSS/Mapa.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/008bdacdcb.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <input type="checkbox" id="Menu">
        <label for="Menu" class="icon-menu fas fa-bars"></label>
        <nav class="Bar">
            <ul>
                <h3 id="ecosta">Ecoestacion: ---</h3>
                <br><br>
                <li id="Carro">
                    <input type="button" id="star1">
                    <label for="star1" class="far fa-star"></label>
                    <input type="button" id="star2">
                    <label for="star2" class="far fa-star"></label>
                    <input type="button" id="star3">
                    <label for="star3" class="far fa-star"></label>
                    <input type="button" id="star4">
                    <label for="star4" class="far fa-star"></label>
                    <input type="button" id="star5">
                    <label for="star5" class="far fa-star"></label>
                </li>
                <br>
                <li class="rutas">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAjVBMVEX///8UFBQAAAAMDAwREREKCgoGBgb5+fny8vLr6+vm5ubv7+/19fU2NjbCwsLY2NiPj4+ampq1tbXe3t7Ozs5DQ0NQUFBWVlZISEh3d3csLCyoqKgfHx9eXl6vr68zMzOEhIRtbW2ZmZkmJibIyMh9fX1vb2++vr49PT17e3sZGRlkZGSMjIxbW1uioqKqnCygAAAIO0lEQVR4nO2c6ZaqMAyANS0wIo6OjrvjOrvL+z/epWIXoAWVgpc5+f7ce0YObZo2SZPSRgNBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEAS5C7+/3YyGk/H09Nx+dF9KoLueQYjrOC77d3JqPbpHdnmeAJCmggOwGTy6V/YYTMBppgCYeo/umSW24Kbli2R8f3TfbOCNQS9fCIXeo7tXnKeOWUCmxumjO1iUYJUp4B8QcZIjYChivSfqT0xABy7QmIjPj+5lAZ5VAQG+t69+uzV4XhPVOVKosdNwqSLHXvHwXzNFdvh8XA8LspViuG5iLvaUqQrdx/SvMJ4UAmapMPRL+XX/iO5ZYC5USBaazYSySMGvvnc2GDrZ01BO4pp6DF8KcNA/0eFD4HxX2zVLiElqdAfvcgxqOU03vP+wNj2y424R+hV2zBrffA6anUFPDEIdF2LQ5N4AjM+8CgnfKuyZLdq896RjfEYYI2dYYc9s0bpCP94Vo/D/IiXMiFhqLaGYpc7I+MxTrWepsDTUbGkGtbY0MmgDY/J3WWtv0fgU3V+aHnkTj9TS4y9zF1m75lGbEnkbEr/rWpvSkBWPOslM+3tXDsG62p7Z4iAl0GVivJlIR8Gr3Za9dqvVDuy+U0dX2cSnd4ieTKXShcVWW8vP4YKlLJud/ansBJBUUjq17X8r8q9ttejNJ6FsDg1dMaUk/O+sV2qdcqumDFexmThX61HWcm1bSJbxQik/S5SxDbG2Rv3L0vBPOzXtbSuH8ezEk+l8/GBr5/063lQRm244afYfP0cnUQ82RwQ3MdXKd26gU5oaXyHRFlsabqIjGXHrDTwNM2pAYNtYS1aa6naqeRsxaXuWISAb2bLKP/3c4lpWYH49QbaAbKKUpcUFyW7ZUok0WaakjptomNgYSB2n/AqphUMnB7UVGq713WjcgbhBc0uKfb2mycBxAS1UZbqqgADry4QcnGaqeS1rD5qnRBsq7Eh7RuCgJtj7VA06ytmi5SjRhgoVcwa7RHgUHJUfN8Xb0pGtRLsqhFW6ijctv4j3m6FEGwVuGVbQpu7MowysTDWwosyzgg0LoyqVpPd5gRhiq7s0FbNPhJ/ib/cWoj5imBD9nCEojjmwgafib+/mp7NEOqW0XUbHEJ1a8VBiEbhj0yPC2MHRQoM63vVKtHNU6EN0f256RGT9yMpCg1r0BzDNXbrp3TxZkJEpAFFgsLAstAx0EhpyjLciS83m4/GT/AJDUaYaEeHLyqs7woyYn9lD6RK20hkGd2Ln1f+JhPJMglShpQTbNTOQz2SaMZOL4iVjN2thsDzUYnbn4mTPrsSDnsu4Eqm1KFg6uxfTIyIoyChHWyDu9u0FwcLZmgtY8tjO2larmT2JVGhtujwJI2Zc2VQ8Ycd8mxipefxTCe81WecXGbmW5fAjFLdPmhbfqwigDZJ8oWS31GXYUKye3bK9rDVrk6KezEonZ47fP4w7s92sM/qYv9pQrxhMy8dJ5UldkhYxULL9MY/p91i+0SWEEhJ9MPhSPKPCtwGWP+hSMkEkWeXp7pTT9Mr2qvuWKA81qcM+lygY81xiN8dSvMZRi3gURopFba9VMeTaaG9Au9sJhXwrNvqREq1/k7dXu+vC8NQNF5U36O8h7qH480u9fNEwwKyIkTgbBfuHuhNFPPHxUfzPIsjYGwuNZwj83lnQ9JbRaJdw/mmWW/9pijROTh2OQWFxVx/nM6ZEgBKc0jK30yK7PqCxZyMzCk5CqwRWdywlYFXKoF9KqZLk1H+afOsxUI8yhNN5N/7obQ+b8/mU2DscGN/qPLZAaWlfb7/kKjEK6XwiBQQYzuUGZ7DcJxYuwPSmKKAdDhGBU0mBoZdtPJoXAx7sRGxMYZwK1L+OcUXCTeHzOWRjxctyzlluc5QYnY+U8Q38atdZuwfxTyMXVy9H/hmXU1LGMkie8NCpUKlw7I27t/lOlZHA8bqtevBLlJbKIJ0IiqmQrUJRXaDZ2f157DwTxGuuJnjUAcbMe1GCpMFPqbAl88J5qegTUWSk8Ju/svgqsZedSZNlTs+GdJSf/hcEa9WuEpjkJAa/qjiw7lGzEpkvFBWc6wpQ/lFdji7ss3TzKvaFdvL4BsyVWLY2xBy9uuz8Hj/JkXHG8T0/VWQHYyWWHRbglsC9wZifYiFAGAHo9XiSAhoTmnb4MiiRJZ/f77IETz+xa1nC3WM6TdJSzgmUVZ4UfGsrsZQlL3i29taKXncSSwUArF5iQ8RCBP6jU2ZGPSJ12DPq1Vq6wju8VX8Ri+QIwPf6y2eyeD7bY1P5SwUfjRw1IlInaDQux5bu8lbeFjQ77MVsEb/hg1Ryb4KuEsuiZ56rutNbPX2k0x40sWFzKroY4iPVk3Ol+TLUZHfve1ufkL17gUVF3zW1U/1gpQoesxbZ1/jTDBkpHCv4fiUiGbuxRD5PihdMgbUO1HCl1237yKIk3D5bHSLsL5pA8fqjdEon3PNuKr1dL34Aizl77kOsfInrn4bq5wbMrH5UfbNezO0zZ8/LGraMXfv5MOIJ2e/De/UXJKluP+bs1zZb8fxBd/Co+y3lAaxzpfmyMKGe16dokW6fhfoX40qcv3TXJq/E0l+vEUROjNb2KiotvBLL9hHRlxiaymm9ibKGLEaLLm2Av6XBBg9imArZ1+IUhuUewXgEbCXSpndWYbUhVVW8Aj1fjdoDAqNaXmaQy8ll5UKvYMn6vyZg8cZy+idu8UUQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBHkA/wAdPlkWic/+kgAAAABJRU5ErkJggg=="alt="">
                    
                    <select name="Rutas" id="rutas" onchange="GSV()"> 
                        <option value="">Rutas</option>
                        <option value="EPM Florida">
                            EPM C.C Florida Cll 71 #65 - 150.
                        </option>
                        <!--<option value="EPM Itagüí">
                            EPM Itagüí Carrera 52 # 60 – 110
                        </option>-->
                        <option value="EPM Laureles">
                            EPM Laureles
                        </option>
                        <!--<option value="EPM La 30">
                            EPM La 30 Carrera 65 # 30 – 40
                        </option>-->
                        <option value="EPM Las Vegas">
                            EPM Las Vegas Calle 57 sur # 48 – 25
                        </option>
                        <option value="EPM Mayorca">
                            EPM Mayorca Carrera 48 # 30 sur - 48
                        </option>
                        <option value="EPM Molinos">
                            EPM C.C Los Molinos Cll. 30A ##82A - 26
                        </option>
                        <option value="EPM Nutibara">
                            EPM Nutibara Transversal 39B #79 - 41
                        </option>
                        <option value="EPM Plaza">
                            EPM C.C Plaza Mayor Calle 41 # 55-80
                        </option>
                        <!--<option value="EPM Punto Cero">
                            EPM Punto Cero Diagonal 64E # 67-405
                        </option>-->
                        <option value="EPM Sabaneta">
                            EPM Sabaneta Cra 48 entre las Calles 72 y 73 Sur
                        </option>
                        <option value="EPM SantaFe">
                            EPM C.C Santa Fé Carrera 43a #7 Sur - 170
                        </option>
                        <option value="EPM Saopaulo">
                            EPM C.C Sao Paulo  Avenida El Poblado No. 18Sur - 135
                        </option>
                        <option value="EPM Tesoro">
                            EPM C.C El Tesoro Transversal Superior Carrera 25A # 1A Sur - 45
                        </option>
                        <option value="EPM Unicentro">
                            EPM C.C Unicentro Cra. 66B #34A - 76
                        </option>
                    </select>
                </li>

                <!--<li class="Con">
                    <img src="https://icon-library.com/images/connector-icon/connector-icon-20.jpg" alt="">
                    <a href="">Conectores</a>
                </li>

                <li class="Foto">
                    <img src="https://www.mcicon.com/wp-content/uploads/2021/02/Technology_Camera_1-copy-18.jpg" alt="">
                    <a href="">Fotografias</a>
                </li>-->

                <li class="LIN"></li>

                <li class="Herra">
                    <img src="https://365psd.com/images/istock/previews/9950/99506249-caution-icon-sign-in-flat-style-isolated-warning-symbol.jpg"
                        alt="">
                    <a href="ResolverProblema.php">Reportar daños</a>
                </li>

                <li class="Herra">
                    <img src="https://www.clipartmax.com/png/middle/272-2728705_pump-icon-fuel-station-icon.png" alt="">
                    <a href="MisEcosta.php">Mis ecoestaciones</a>
                </li>

                <li class="Herra">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAgVBMVEX///8AAADKysri4uJBQUHs7Oz6+vrOzs7l5eUaGhr19fU2Njb4+Pje3t75+fnp6emsrKxgYGDU1NSLi4uFhYW1tbVxcXFnZ2eXl5ePj48nJycxMTHZ2dmrq6stLS2/v79HR0cWFhagoKBMTExXV1chISEQEBB4eHh+fn51dXVaWlpd42k9AAAOZElEQVR4nO1d6WLyKhCtW9SorVs0rnGrn/X9H/C6zABDyAKC2l7Or8YmwAFmYZiQjw8PDw8PDw8PDw8PDw8PDw8PD49fj6BZLYNm8OqGmmJVKYvVq5tqhmZpgpVK89WNNcJUg+H01Y01Ql2DYf3VjTWCZ/hnGC7qeVj8AYbD3JuGf4BhviFoeobvDM/wBs/wrfG/YRi1atloRX+A4d/3aTzDX8xwo8Fw8+rGGmGkwXD06sYaIdRgGL66sWYIT/M2Aph8X/78hr/Z/+anX0pQBIxn53bR+dXjloGGgmHjxW2yC8/w98Mz/P3wDH8/PMPfj7/PELy2edLv95P5X/PavobReKBYTwzG0fDr1Y17GK1o0lGQ4+hMot6rG6lAbRWVmGLd5F8uOY5/Sbe4uDBa1R5vejnMrq2q5t8TRjqb3JXKNCpQPNXrXbE9EnmY3duUR7E52Wrxu2GSV2L1fs/MNhkVWPglM5i9muvTu+F7l5VZw/I6nkBRiC8p+7yRFYDaruubw3kwHZwPm/p6m3HXSKldq8INbulJAbQ0xa+xotXzq13oNcTxCRq9qw1RDfY4zbEq/t8xxRltjTRRg/T4rcdRI1tRdhvReJ3m+EnvklKPnE7UFANCsS//99wvY9Eb/YP8IMkCS+VWORxFhYjxiTqUovjnIv0vIIwkkh3eddVKCs4ocoKCsQOKARXA71lLs/BW/E1KOIHYcoKTyDXFmFXQ//g4s4tbNsmQ6IxFYpJPGSQLsZD5rWA+RQdisqMT01/jI3i95KPYlKbvRm0ogzCsNZMrmrUwVHdBlezmjMURvOX2cUnXnSJlkGDhoAY4xUQUok2S5taqxj97Ogm/Dz9xtZXmmYgcD3xeQvLijtXpgCGbLwf44VxRoC8/VusPslcXnUE/tbLoHxU3DuCfe/zBRULqJzNce+j69KLvJFmy4aidukdGe7SUKjql7oERDNgAr50kTnNB3IMNl5YPC5rC9hUX0wOSM2o3h9KoA8Eun8GO1lE9TjFQUKQqvKpa1mdjQD1A4jvhCLIpWnG2aBYo3n/oCu0gkhHlr+xVWBDlIToy0J18BB1GBfhE3VyrDTmPveh8RurlUxslea2evu1IKKPLR6xzDSh0n0KQyOLnR4MTFGdoM52iUJ/sqsuLEweXF190Wd1N0skaxJRyI3uh6F4GEcJEbfAWCp0f/kitno8TpkcYwzu+kvFCuvtHcGa5Ndw0njSClCKHoCUi+p9tTHpcYnhFLd7SR4TeUjjd7gmKExVZ8EpDqkAnsl1WMPy4RnXIU1Mex+tJ7J1PUaiW1tnmlTbFBm3j9OpJzfAilmQgt3xO1Kiv9xyCMkVurHfizztVRDWL4WX06cPs9y9S19OCxz3uOh55r4pzbaz2qu7PHZX/+xRXmBP2c02o64nRca4CmE8ZCjbikNWUux6KMv5bE9YoGzYFluy3giC0VRxSlTYEtZ9aX3D0F5VFFsEPEulZMClm3XnIftA24hSXL+7FbHKjT0HG2hfL4TNhzsphvJ8U1GfvuQiezBcXlkdjfYLPzdbxzLvJf//GHlCDs1kTblmrHl97s1hCZctkEaXi++HSSwF13hElJWQyeFzmPlkOSzYhFkixgT+NLZRf3ICUluGrACuSwmN6uEgTtI2NLiwC+tusO4nPVSSGYa8oTkwWv8wu4sTZmDe8LFCxdfAH4owUjeKocKbFtDj0bgKUhBxTZAcBSgQ61cOKhDyKu8I7Yrk4VJ+46D+6fnkf59AJrpka5fYix/WAO7Jv4IoUy2ujtsEInOM9UpadjkELJoQtFnKfZD9eyJAVt6rJxbGq3ebhoMDj9hdb8CZ8V2GQ/XghwzMvPxGKvgHLd7pFCslblQVcB9iKmdCEHDErZBgLHcg8GZQ8DGS5TBdDKcRuxUkFdutGcZPzfCHDoC7MEPRRf+CfOKoOJTGEKOAGrpkexV4d/ptmplNcUcjwI9gNflB94oxh+hQot91JItpCHEJ0F0vbqGKGBCh56AAnuvVpA+KjaOwTqQHF0GTI/EHsUqkB1oGTEpew6L+VDy7oMsSIEL68h6rb1SrqhzYQh1DD39dlyKwTDiJc/itfgg7QNKA9Qk9RQ+61GaKZR/OEFsSN64ZjBktvdBR1FkzaDJmfCvOyJY2pXUypXsHwtk536jP8hEfQUQL17eRMIjSGYI4xVKtlfvUZMicD4lJgQJyYxCqtCpeFWi6UAUPsyR29dBE7hdXLGS7BVPzkPiPDgCF6hmgwYJqecp8xQ530JVoqvawPE4Y4d2D7YEcJWwQ6iRAKAh23yH9IhglDXFKAzsZAmP0FBrgTc7isG+gZQ4YjOmoQrc3ZGzAEeBew4kZLrBncM2KIziKoT5BL++vgNem6yKitZgzxKai6byQf5asBL/tkptHMGP6QynpmhRRiScs1FAazxsGEwU0LMwEpWwuIOypWXc/CjKFUGywSbbumYB1gpdSkvVoahhNse38MbC9IyC7/GW1MSbEwojmRUTUMGU6ITIDNt+1806kBL6Vp7zQZMpwRVZMQgbEG2MUG1+lgKAqGDGHKwLoNouHz/Gd0ER6JsNcJ3/IwZNgjowbextbuAgp3Ee6lhmAstN9xNWQIS6ZvqB1KsZuuD+Zw/amoUQOGDHGD696jmHBu1yCCb7i5X8GILnqtKzSK0Wd4q6G3JlIBoW+7IcUmkXWepnRFu7xl0mW4o8nE4DKCnrP7QgIwhHgQZahhNTQZyhvCMC8HDhmClZUZlm4y3F525SNXAwynDhmCE5NiWOJlc9LkchRTx6EBw8kbjyETq3IUXzCGGXJYehHFExFKUZSSxp8hh6BLcRH6fTtQbq+xSuRvEJaK8ESbWw2YSOdSl6rtYaMbXqBVEKdYUhYv6DaeYA9h1Obg09y9VCPPkCfJlt+Vg8S9492n6c7JiFoCBtPBM4Q6jM5e0R1FXvuc+qV2T35Bz5CuLcx6UZ8iaDZpbVHWRJWEcn1oGJXt61Kk60OUGLPKMwHSDWteCJWYJrboyuKI3Ax8N4aVZwH8CBqnMQ6VaI7igEwZiNPo7XoVA4qFUAmYx61xcZximYUJ3Oo21gbeCMTS8d1R8w0gTrG4DFTkoFrWRGCsAVME4HLxkKq5glEsNtzSTgU8Z/3MASgXXEO6E2WEfumWTomikfYX7AECppBSllio5k7xXHxjhUxL6Bn7m8AQlQX1iUkgD3m/ycUZGxTbbdzmpucc2H9DCEatDZeQU/dgwsCyjDBBgB3fvWi7UTSpXV+wHnP3n73rwtoJrIO0I2wTG1IR6lb37wSiyIOjDdGpjYOaZnSywDTNSVu3hIGyXheZ0Dg9QHRQ2bt+9xj3E0CJ49xxkWEaUnnAjVnXb5PhiyTg+qD8O0n1/qESgPm0bl/wQAWHfvaGXtoF2iVY92I4yu0gnmil6NA4UnBQOtpATDN3eY4sOt2oZ5Cwo+rGtHhMEnYzY+7AV1bQd3I8b1CP4crsIFVvH9iJmJeMSa0uzjK7AeblWqrf3Yd+OrQPgzmds/aB7gUuCzHV29V78ri7htESjPK7yWO/IoDlNb6zwt4RRLMfdbbTxxRPOF7vkUBPLh6GdOHQGUY5wEHENHOoc/SwkNzjsneXDOck89BwCG1HaEgDIOkE11Ds8IHbSyw0sccIM2Haox5luWWwbrKcZiIBJQMlj70n3+cD+ojiOfDyWWgcrbtctyNgtRgh40dWsPfoH0k4Y+8Bx+zANoyosrcRH2RQhJ1EI0gfPfeIeUx/rZzNCDzfz/l32PF9LlR4qYOxHmtB6ixi1KNoqexnP8vAmtqB9IOlLl7R4lBrf2IKgDtbyIBmnokbOcji8RdYCUW2lMc56j6mwL1THvCe2CRIJirrRZaz4MwjFcGO+mDeCz++xca6jR+zxfxP1qsujb0AVJ+dQP7FRhP4WSnshWamsJ294iwhdWSFeMzn5DPv0UJ0+aGvdea78MM3HipbA+nDt4TT2ha5YbCwl+tzDfmhaPzEtvTRYu7BOpppG36IcW4sMz5Wjjlel6CWN0wEmJZx8mpsBgJ2YCNXLcKZwusst2aXK6tN4ehazoYpHtupCfngngyfk6JdnKolBv6rLlI8dplPA+7HPe07OnfwpDqebk28m5OKYzbDL3KIN3dclorfngSev8tHsUXOzP1Jd3oWwx45L2zBO4efQvUkSyiCH8YpmHn6BYx9JO1/Khl2oz15SkhA4cb/KUfRyeByI2jxJj36+PivKuZapBmGVelkZVFLcf/tmWpUAD80WDAAgZx+fhys2DyWGA5XZ/lk71iIMvGSnuFvK8FPVJ0KDWsovtZVH6+SlsCwlazGim+vT4UBD3gxTzy4VAYfxbWoVobKD0MU4iB6QzX+DaGXjeAVwnCR7KGh3ncDbjyItyekeD+StGMBghmbkkBtK/2VijyciGkRZqiT8yG0IB4MKRllyQpkQ86FF12HF9hBGWJzZGet0R8UfcXjmPrsVUvUVE/3ZFSoiSZwJu8phM1Ztt45z5pyamIgureLJ/uiWRClprJVBdtqUSx9rbMziSNV81dbcUq4z0cqCxLlPEZZDQtrveVw2atlLYID+p2gJy54i1EjSuV7Z5Ja29iRT5vs32SGMkiR3IluSs9Q+iyr8+C9PhqSkf+Oy8eN5M/KVQbv+cHnqrxLUx8Ni/f6wuVM9lA7z/xGgB5W0lBcRnIQD7PHozGMB+lH3krDyAhWcnuvWA/iqErt+lc1is/pD3ReBfB9TEQG+jkfs2qvO/VOxteebli8oYJRIDFbPF1cnLfw0UqhJX/iqATas3czgAVYjlTfMczE+FmfrrCK5W5fhuVxH/9KendczME07yvd82l6dfH70G00d7Op/IG1xXS2a+Z87vlX4rO1HDarzeGy9dgeo4eHh4eHh4eHh4eHh4eHh4eHxzviP74CqOj/EN/oAAAAAElFTkSuQmCC" alt="">
                    <a href="Cargas.php">Tiempo de recarga</a>
                </li>

                <li class="LIN"></li>

                <li class="datos">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAeFBMVEX///8AAAD5+fn29vbz8/Pm5ua7u7u3t7efn5+JiYmbm5t0dHSUlJTU1NSkpKQ9PT3Nzc3ExMQYGBgQEBBqamrp6elISEiwsLAhISE4ODiCgoJ7e3vd3d1wcHBdXV1DQ0MvLy9VVVUsLCxiYmIlJSVOTk4TExNXV1f1Y3UPAAAFoUlEQVR4nO2d2XbaQAyG4wWXsIXdkJAU0iZ5/zcsrktjB9uZRbL+4ei74nL+Mx6NthF3d4qiKIqiKIqiKIqiKObEg3w03u6igt12PMoHsfSSCIkPk5fompfJ4TZUTh+PDfJKjuOp9PK8yfet8v6JnEkv0Ydk+I28klEivVBX8qWRwChahbmP0wdDfQX7AM/jo4W+gifpBVtyaLefbfw+SC/ahsxaX8EP6WWbM3ISGEX30gs3ZewoMIrW0ks349lZYCAS3XcwEIm2t8RXxtICvmPmKfDsw0lL6GbuLTCKFtIiukjfCRRGG2kZHXxQCIy20jLa8T+EJbBHMSUSiPudrskUvkhLaYbCjl7AtKcnQoU/pcU0QbmFmJtIc1NcANzEA6nAKMJL3Ph63F95lhZ0BbHAKEJLoi7IFaJlbXwC+2bAbv34lVzhLpUWVYPakhZgWVOqqKLKRFpUDb/0UzO/pEXVsKnCmLJDqhAnDAKjCMnUDFgUIpka+vu+AOnOz1kUDqVlVTCr19uCdF24ltO6QSq2TVgUPkrLqsCjEKm0z6MQ6SvlOYdIlobD8cZK7v9gUYjUKTVlUYiUM6WryVRBqs/Epj16VkBl25p6gH3BKpTeMyhEuvB5wiek4OnubsOgcCAtqs4buUC06hN9hIjksxXQZ2qQsjR/+Uks8Cgt6Aq3tuB2cmlB1xArREoH/4M2CkaKfi8kK0qFSPnu/1AG+ohbeA4wdmQCV5BbSBnpAxrSkhORQDSH7RMq/xvM565CU6FBykBd8UQgEK8bqoZ/uXsP6M1USb3vfaQMWyO+nTVwQdM1ftnhufTyTfCRGITA84fqfBYD+ERLUjeLuoc3MhVc7kXwe/Ar9t4NrLfdxuZkpW8L7Iu2kpkXpN6xMvjGxCOz54irCbij1kEyNLg4RqABvSnZtlPeNtDvs8ZmdmreydXbLET70shmPlnXZ4Ec15N5SBe8CXE6WOSz4Wg4yxeDNFzboiiKoiiKogROfCbZDNKk+CG9GFLSwXx2Pz7tq0mN5f40vp/NB4EHv2em+fjtd0cAvHwb58Gkga84DLeGeZrtMDyVSWabE37OoNq6u0kyt2lD6yyMY3l4dO+rWT7hf66Z/WjWOkfo5Fs6onh38Q6bQE3puhMnkBppn1zgte7Rv+bGqrYtvpst78Ie5+1ayjH3o+AZ5DjyjBsoQfhUU45na598iG9jRtrd3UQmK5B6SlsTkq/0NhyDd66R67OhnQXZhVAzGM8j/GZE2ob7OIKfCEwBoRupa0bf4+hj2mmlJpx6zUDG/RjROg89Soypn1OiSUxkBJ4l9pWOkxLY23OhX2ICe5qlyBUMmtHDH3zwjIQyh/2ZPvWTbXuYoymOWbO2sP63V8oyaceSJWfY37cz2gyjQeUZAGkP21BMhENYwnUUfctKdLzyCOSYBeUKS1mDZ+qcKxyVVI7ShDt7eoEodvQCuT3lmRvoA/W9j3HXVyF+rohlZkpojc1JWk4DH5QCeWau+0KZ6+9+fyYF4XDM/kowdtBtolxyrRuy1BuiIS2hMqeS6cNuiMo1PH/PQQPNG1Tp/GEXJLlFhj+rouOVoliDedtfoOgMw/O5qxDYmlhawzf4f6Y8fwpAh3/TNG/bmj/efyKIF9t/xTfWx7akBb7WVLYeaoJvYx9WDrEJz7wisk96wc835exwpsKvU5piWic3fgdRorvLFq9In+e/Kanx6ZRCTUHV8UlI9dkG7I5PA3G/fcCu+PQP49/3BQ8eCqXXbogqbAenvaQb9+YT/NCpxD2AQs9gXHDPZITgdxe4+97I2e4q7plv/AC/xL01GjsZ/Il7Wvj29zAMx9vH9b79Gz+IEN/P8779CDiIG9GzDozUGNyMd7uwxex4CZYET2jibM0+N8GR1Tq7reF9iqIoiqIoiqIoiqK08we7LGaJQSXemgAAAABJRU5ErkJggg=="
                        alt="img_usuario">
                    <a href="">USUARIO</a>
                </li>

                <li class="LIN"></li>

                <li class="datos">
                    <a href="inicio.php">CERRAR SESIÓN</a>
                </li>
            </ul>
        </nav>
    </header>
    <div id="rut">
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126916.74073834557!2d-75.65125209709198!3d6.24419882131964!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e4428dfb80fad05%3A0x42137cfcc7b53b56!2sMedell%C3%ADn%2C%20Antioquia!5e0!3m2!1ses!2sco!4v1633393536809!5m2!1ses!2sco"
            width="100%" height="736px" style="border:0;" allowfullscreen="" loading="lazy"></iframe>     
    </div>
</body>
<script src="Js/Mapa.js"></script>
</html>