<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="icon" href="img/Logos (1).png">
    <link rel="stylesheet" href="CSS/inicio.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
    <script src="Js/inicio.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
</head>

<body class="animate__animated animate__backInLeft">
    <div class="fondo">
        <div class="container">
            <img src="img/Logos (1).png" alt="">
            <form action="" class="container__form">
                <input type="button" value="Iniciar Sesión" onclick="Log()">
                <input type="button" value="Registrarse" onclick="Reg()">
                <br><br>
                
                <input type="button" id="nos" value="Acerca de Nosotros" onclick="acerca()">
            </form>
        </div>
    </div>
</body>

</html>