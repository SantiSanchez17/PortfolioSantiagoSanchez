<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="utf-8">
	<!-- Se habilita el Responsive en la página Web -->
	<meta name="viewport"
		content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Vincular vehículo</title>
	<link rel="stylesheet" href="CSS/vincularVehiculo.css">
	<script src="Js/inicio.js"></script>
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Bree+Serif&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
</head>

<body class="animate__animated animate__backInLeft">
	<div id="titulo">
		<h2>¿Ya vinculaste tu vehículo a EPM?
			<br>
			<br>
		</h2>
	</div>
	<div id="parrafo">

		<h2>
			<p> Es necesario que tú vehículo esté vinculado a empresas EPM para que puedas acceder a las estaciones de
				recarga.
				<br>
			</p>
			<p> Ingresa al siguiente link. Allí encontrarás toda la información necesaria para registrarte</p>
		</h2>
	</div>

	<div id="flecha">
		<h2> ↓ </h2>
	</div>

	<div id="link">
		<p>
			<a
				href="https://www.epm.com.co/site/clientes_usuarios/clientes-y-usuarios/nuestros-servicios/energia/movilidad-el%C3%A9ctrica">
				<h2> Link </h2>
			</a>
		</p>
	</div>
	<div class="botun">
		<button class="boton" value="ACEPTAR" onclick="Mapa()"> ACEPTAR </button>
	</div>
</body>