from tkinter import ttk
from tkinter import*
from tkinter import messagebox as MessageBox

import sqlite3


#Ventana del Index
class index:
    def __init__(self, window):

        #Variable con nombre de la base de datos
        self.db_name = 'database.db'

        self.windIndex = window
        self.windIndex.title('MiniMart')
        self.windIndex.geometry("650x350")
        self.windIndex.wm_resizable(False,False)
        self.windIndex.config(background="#B4E197")

        main_title = Label(text="Inicio", font=("Cambria",17), bg="#4E944F", fg="white", width="550", height="2")
        main_title.pack()

        Button(self.windIndex, text ="Registrarse",command = self.Registro, width="30", height="2", bg="#4E944F").place(x=215,y=100)

        Button(self.windIndex, text ="Iniciar Seción", command = self.Login, width="30", height="2", bg="#4E944F").place(x=215,y=200)


    #Ventana del Registro
    def Registro(self):
        self.windIndex.withdraw()
        
        self.RegWindow = Toplevel(self.windIndex) 
        self.RegWindow.title("Registro") 
        self.RegWindow.geometry("350x280") 
        self.RegWindow.config(background="#83BD75")
        self.RegWindow.wm_resizable(False,False)
        Label(self.RegWindow, text="Nombre", bg="#83BD75").place(x=22,y=30)
        Label(self.RegWindow,text="Usuario", bg="#83BD75").place(x=22,y=90)
        Label(self.RegWindow,text="Contraseña", bg="#83BD75").place(x=22,y=150)


        self.name= Entry(self.RegWindow, width="40", bg="#E9EFC0")
        self.user = Entry(self.RegWindow, width="40", bg="#E9EFC0")
        self.password = Entry(self.RegWindow, width="22", show="*", bg="#E9EFC0")
        self.name.place(x=22,y=60)
        self.user.place(x=22,y=120)
        self.password.place(x=22,y=180)
        
        Button(self.RegWindow, text="Registrar", command=self.register, width="30", height="2", bg="#4E944F").place(x=22,y=220)

        Button(self.RegWindow, text="volver", command=self.volerR, width="5", height="1", bg="#4E944F").place(x=300,y=5)
    

    #Funcion Volver al index
    def volerR(self):
        self.name.delete(0,END)
        self.user.delete(0,END)
        self.password.delete(0,END)
        self.RegWindow.destroy()
        self.windIndex.deiconify()
    
    
    #Ventana del Login
    def Login(self):
        self.windIndex.withdraw()

        self.LogWindow = Toplevel(self.windIndex) 
        self.LogWindow.title("Iniciar Seción") 
        self.LogWindow.geometry("350x250") 
        self.LogWindow.config(background="#83BD75")
        self.LogWindow.wm_resizable(False,False)
        Label(self.LogWindow,text="Usuario", bg="#83BD75").place(x=22,y=30)
        Label(self.LogWindow,text="Contraseña", bg="#83BD75").place(x=22,y=90)

        
        
        self.usuario = Entry(self.LogWindow, width="32")
        self.clave = Entry(self.LogWindow, width="22", show="*")

        self.usuario.place(x=22,y=60)
        self.clave.place(x=22,y=120)
        
        Button(self.LogWindow, text="Iniciar Seción", command=self.log,width="30", height="2", bg="#4E944F").place(x=22,y=180)

        Button(self.LogWindow, text="volver", command=self.volerL, width="5", height="1", bg="#4E944F").place(x=300,y=5)


    #Funcion Volver al index
    def volerL(self):
        self.usuario.delete(0,END)
        self.clave.delete(0,END)
        self.LogWindow.destroy()
        self.windIndex.deiconify()


    #Conexion a la base de datos
    def run_query(self, query, parameters = ()):
        with sqlite3.connect(self.db_name) as conn:
            self.cursor = conn.cursor()
            result = self.cursor.execute(query, parameters)
            conn.commit()                       
        return result


    #Funcion de Verificacion de parametros nulos (sin llenar) para Registro
    def validation(self):
        return len(self.name.get()) != 0 and len(self.user.get())  != 0 and len(self.password.get()) != 0


    #Funcion de Verificacion de parametros nulos (sin llenar) para el LogIn
    def val(self):
        return len(self.usuario.get())  != 0 and len(self.clave.get()) != 0


    #Funcion de Registrar
    def register(self):
        if self.validation():
            query ='INSERT INTO login VALUES(?, ?, ?)'
            parameters = (self.name.get(),self.user.get(),self.password.get()) 
            self.run_query(query, parameters)
            MessageBox.showinfo(message='El usuario {} se a registrado exitosamente'.format(self.user.get()), title='Registro')
            self.name.delete(0,END)
            self.user.delete(0,END)
            self.password.delete(0,END)
            self.RegWindow.destroy()
            self.Login()
            
        else:
            MessageBox.showwarning(message='Porfavor llene todos los parametros', title='Registro')

    
    #Funcion de LogIn
    def log(self):
        if self.val():
            Uss = self.usuario.get()
            Clv = self.clave.get()

            query = 'SELECT * FROM login WHERE user = ? AND clave = ?'
            parameters = (Uss,Clv)
            self.run_query(query, parameters)

            if self.cursor.fetchall():
                MessageBox.showinfo(message='Se Inicio secion correctamente', title='Login')
                self.usuario.delete(0,END)
                self.clave.delete(0,END)
                windowM = Tk()
                Menu(windowM)
                
                self.windIndex.destroy() 
            else:
                MessageBox.showerror(message='Vuelva a intentar', title='Login')
                self.usuario.delete(0,END)
                self.clave.delete(0,END)
        else:
            MessageBox.showwarning(message='Porfavor llene todos los parametros', title='Login')


#Ventana del Menu
class Menu:
    def __init__(self,window):

        self.wind = window
        self.wind.title('MiniMart')
        self.wind.geometry("400x300")
        self.wind.wm_resizable(False,False)
        self.wind.config(background="#B4E197")

        main_title = Label(self.wind, text="Menu Prinicipal", font=("Cambria",17), bg="#4E944F", fg="white", width="550", height="2")
        main_title.pack()

        #Inventario (Falta establecer ciertos parametros)
        Button(self.wind, text ="Inventario/Bodega", command=self.Invent, width="15", height="2", bg="#4E944F").place(x=40,y=100)

        #Ventas (Esta en proceso por hacer)
        Button(self.wind, text ="Ventas", command=self.Ventas, width="15", height="2", bg="#4E944F").place(x=145,y=200)

        #Ganancias (Esta en proceso por hacer)
        Button(self.wind, text ="Ganancias", command=self.Ganancias, width="15", height="2", bg="#4E944F").place(x=260,y=100)

    '''Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario'''

    #Ventana de Inventario/Bodega
    def Invent(self):
        self.wind.withdraw()
        #Variable con nombre de la base de datos
        self.db_name = 'database.db'

        #Config de la ventana de Inventario/Bodega
        self.windInv = Toplevel(self.wind)
        self.windInv.geometry("800x400")
        self.windInv['bg'] = '#B4E197'
        self.windInv.wm_resizable(False,False)

        #Contenedor
        frame = LabelFrame(self.windInv, text = 'Registre un nuevo producto', bg="#B4E197", fg="black", width="550", height="2")
        frame.grid(row=0, column=0, columnspan=3,pady=20)

        #Producto
        Label(frame, text='Producto:', width=8,bg="#4E944F", fg="white").grid(row=1,column=0)
        self.prod = Entry(frame)
        self.prod.grid(row=1,column=1)

        #Cantidad
        Label(frame, text='Cantidad:', width=8, bg="#4E944F", fg="white").grid(row=1,column=2)
        self.cant = Entry(frame)
        self.cant.grid(row=1,column=3)

        #Codigo
        Label(frame, text='Codigo:', width=8,  bg="#4E944F", fg="white").grid(row=2,column=0)
        self.cod = Entry(frame)
        self.cod.grid(row=2,column=1)

        #Valor Unitario
        Label(frame, text='Valor Und:', width=8,  bg="#4E944F", fg="white").grid(row=2,column=2)
        self.val = Entry(frame)
        self.val.grid(row=2,column=3)

        #Boton de Guardado
        Button(frame, text='Guardar', command=self.add_product, bg="#83BD75").grid(row=3,columnspan=2,sticky = W + E)

        #Boton de Volver
        Button(self.windInv, text='volver', command=self.volver, bg="#83BD75").place(x=720, y=10)
        
        #output messages
        self.message = Label(self.windInv,text='', bg="#B4E197",fg='red')
        self.message.grid(row=3, column=0, columnspan=2,sticky=W+E)

        #Table
        self.tree=ttk.Treeview(self.windInv, height=10,columns=('Producto','Cantidad','Codigo'))
        self.tree.grid(row=4,column=0, columnspan=2)
        self.tree.heading('#0', text='Producto', anchor=CENTER)
        self.tree.heading('#1', text='Cantidad', anchor=CENTER)
        self.tree.heading('#2', text='Codigo', anchor=CENTER)
        self.tree.heading('#3', text='Valor Und', anchor=CENTER)
        
        #Boton de Eliminar
        Button(self.windInv,text='DELETE', command=self.delete, bg="#83BD75").grid(row=5, column=0, sticky=W+E)

        #Boton de Editar
        Button(self.windInv, text='EDIT', command=self.edit, bg="#83BD75").grid(row=5, column=1, sticky=W+E)

        #Llenando tablas/Refrescar la tabla
        self.get_product()


    #Funcion de volver al Menu
    def volver(self):
        self.windInv.destroy()
        self.wind.deiconify()


    #Conexion a la base de datos
    def run_query(self, query, parameters = ()):
        with sqlite3.connect(self.db_name) as conn:
            self.cursor = conn.cursor()
            result = self.cursor.execute(query, parameters)
            conn.commit()                       
        return result


    #Funcion de llenado de la tabla
    def get_product(self):

        #Limpiando la tabla
        records=self.tree.get_children()
        for element in records:
            self.tree.delete(element)
        
        #query data
        query = 'SELECT *FROM invent ORDER BY prod DESC'
        db_rows = self.run_query(query)
        for row in db_rows:
            self.tree.insert('',0, text = row[0], values=(row[1], row[2], row[3]))


    #Funcion de Verificacion de parametros nulos (sin llenar)
    def validation(self):
        return len(self.prod.get()) != 0 and len(self.cant.get())  != 0 and len(self.cod.get()) != 0 and len(self.val.get()) != 0
        

    #Funcion de guardado/registro de productos
    def add_product(self):
        if self.validation():
            query ='INSERT INTO invent VALUES(?, ?, ?, ?,0)'
            parameters = (self.prod.get(),self.cant.get(),self.cod.get(), self.val.get()) 
            self.run_query(query, parameters)
            self.message['text'] = 'El producto {} se a añadido exitosamente'.format(self.prod.get())
            self.prod.delete(0,END)
            self.cant.delete(0,END)
            self.cod.delete(0,END)
            self.val.delete(0,END)
        else:
            self.message['text'] = 'Porfavor llene todos los parametros'

        #Llenando tablas/Refrescar la tabla
        self.get_product()


    #Funcion de borrar/eliminar de productos
    def delete(self):
        self.message['text'] = ''

        #Verificacion de seleccion
        try:
            self.tree.item(self.tree.selection())['text'][0]
        except IndexError as e:
            self.message['text'] = 'Porfavor seleccione un producto'
            return
        self.message['text']=''
        prod = self.tree.item(self.tree.selection())['text']
        query = 'DELETE FROM invent WHERE prod = ?'
        self.run_query(query, (prod, ))
        self.message['text']='Producto {} a sido eliminado correctamente'.format(prod)

        #Llenando tablas/Refrescar la tabla
        self.get_product()


    #Ventana de editar de productos
    def edit(self):
        self.message['text'] = ''

        #Verificacion de seleccion
        try:
            self.tree.item(self.tree.selection())['text'][0]
        except IndexError as e:
            self.message['text'] = 'Porfavor seleccione un producto'
            return
        prodV = self.tree.item(self.tree.selection())['text']
        cantV = self.tree.item(self.tree.selection())['values'][0]
        codV = self.tree.item(self.tree.selection())['values'][1]
        valV = self.tree.item(self.tree.selection())['values'][2]
        self.edit_wind=Toplevel(self.windInv)
        self.edit_wind.title='Editar Producto'
        self.edit_wind['bg'] = '#B4E197'

        #Producto Viejo
        Label(self.edit_wind, text='Producto Viejo:', width=12, bg="#4E944F", fg="white").grid(row=0,column=1)
        Entry(self.edit_wind, textvariable=StringVar(self.edit_wind, value=prodV), state = 'readonly').grid(row=0, column=2)

        #Producto Nuevo
        Label(self.edit_wind, text='Producto Nuevo:', width=12, bg="#4E944F", fg="white").grid(row=1,column=1)
        new_prod = Entry(self.edit_wind)
        new_prod.grid(row=1,column=2)

        #Cantidad Viejo
        Label(self.edit_wind, text='Cantidad Viejo:', width=12, bg="#4E944F", fg="white").grid(row=2,column=1)
        Entry(self.edit_wind, textvariable=StringVar(self.edit_wind, value=cantV), state = 'readonly').grid(row=2, column=2)

        #Cantidad Nuevo
        Label(self.edit_wind, text='Cantidad Nuevo:', width=12, bg="#4E944F", fg="white").grid(row=3,column=1)
        new_cant = Entry(self.edit_wind)
        new_cant.grid(row=3,column=2)

        #Codigo Viejo
        Label(self.edit_wind, text='Codigo Viejo:', width=12, bg="#4E944F", fg="white").grid(row=4,column=1)
        Entry(self.edit_wind, textvariable=StringVar(self.edit_wind, value=codV), state = 'readonly').grid(row=4, column=2)

        #Codigo Nuevo
        Label(self.edit_wind, text='Codigo Nuevo:', width=12, bg="#4E944F", fg="white").grid(row=5,column=1)
        new_cod = Entry(self.edit_wind)
        new_cod.grid(row=5,column=2)
        
        #Valor Viejo
        Label(self.edit_wind, text='Valor Viejo:', width=12, bg="#4E944F", fg="white").grid(row=6,column=1)
        Entry(self.edit_wind, textvariable=StringVar(self.edit_wind, value=valV), state = 'readonly').grid(row=6, column=2)

        #Valor Nuevo
        Label(self.edit_wind, text='Valor Nuevo:', width=12, bg="#4E944F", fg="white").grid(row=7,column=1)
        new_val = Entry(self.edit_wind)
        new_val.grid(row=7,column=2)

        #Boton de Actualizar
        Button(self.edit_wind, text = 'ACTUALIZAR', bg="#83BD75",command = lambda: self.edit_records(new_prod.get(), prodV, new_cant.get(), cantV, new_cod.get(), codV, new_val.get(), valV)).grid(row=8, column=2, sticky=W)


    #Funcion de editar de productos
    def edit_records(self, new_prod, prodV, new_cant, cantV, new_cod, codV, new_val, valV):
        query = 'UPDATE invent SET prod = ?, cant = ?, cod = ?, val = ? WHERE prod = ? AND cant = ? AND cod = ? AND val = ?'
        parameters = (new_prod, new_cant, new_cod, new_val, prodV, cantV, codV, valV)
        self.run_query(query, parameters)
        self.edit_wind.destroy()
        self.message['text']= 'Registro {} actualizado exitosamente'.format(prodV)
        
        #Llenando tablas/Refrescar la tabla
        self.get_product()

    '''Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario Invenario'''


    #_________________________________________________________________________________________________________________________________


    '''Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas'''
    def Ventas(self):
        self.wind.withdraw()
        #Variable con nombre de la base de datos
        self.db_name = 'database.db'

        #Config de la ventana de Ventas
        self.windVen = Toplevel(self.wind)
        self.windVen.geometry("601x400")
        self.windVen['bg'] = '#B4E197'
        self.windVen.wm_resizable(False,False)

        #Contenedor
        frame = LabelFrame(self.windVen, text = 'Registre un nuevo producto', bg="#B4E197", fg="black", width="550", height="2")
        frame.grid(row=0, column=0, columnspan=3,pady=20)

        #Producto
        Label(frame, text='Producto:', width=8,bg="#4E944F", fg="white").grid(row=1,column=0)
        self.prodV = Entry(frame)
        self.prodV.grid(row=1,column=1)

        #Cantidad
        Label(frame, text='Cantidad:', width=8, bg="#4E944F", fg="white").grid(row=1,column=2)
        self.cantV = Entry(frame)
        self.cantV.grid(row=1,column=3)

        #Fecha
        Label(frame, text='Fecha:', width=8, bg="#4E944F", fg="white").grid(row=1,column=4)
        self.date = Entry(frame)
        self.date.insert(0,"dd/mm/aaaa")
        self.date.grid(row=1,column=5)

        #Boton de Guardado
        Button(frame, text='Guardar', command=self.add_venta, bg="#83BD75").grid(row=3,columnspan=2,sticky = W + E)
        
        #Boton de Volver
        Button(self.windVen, text='volver', command=self.volverVen, bg="#83BD75").grid(row=5)

        #output messages
        self.message = Label(self.windVen,text='', bg="#B4E197",fg='red')
        self.message.grid(row=3, column=0, columnspan=2,sticky=W+E)

        #Table
        self.tree=ttk.Treeview(self.windVen, height=10,columns=('Producto','Cantidad'))
        self.tree.grid(row=4,column=0)
        self.tree.heading('#0', text='Producto', anchor=CENTER)
        self.tree.heading('#1', text='Cantidad', anchor=CENTER)
        self.tree.heading('#2', text='Fecha', anchor=CENTER)

        self.get_venta()


    def volverVen(self):
        self.windVen.destroy()
        self.wind.deiconify()


    def get_venta(self):
        #Limpiando la tabla
        records=self.tree.get_children()
        for element in records:
            self.tree.delete(element)
        
        #query data
        query = 'SELECT * FROM ventas ORDER BY prod DESC'
        db_rows = self.run_query(query)
        for row in db_rows:
            self.tree.insert('',0, text = row[0], values=(row[1],row[2]))


    def valVenta(self):
        return len(self.prodV.get()) != 0 and len(self.cantV.get())  != 0 and len(self.date.get())  != 0 


    def add_venta(self):
        if self.valVenta():
            produ = self.prodV.get()
            canti = float(self.cantV.get())
            query = 'SELECT * FROM invent WHERE prod = ? AND cant > ?'
            parameters = (produ,canti)
            self.run_query(query, parameters)
            if self.cursor.fetchall():

                query = 'UPDATE invent SET cant = cant - ? WHERE prod = ?'
                parameters = (canti, produ)
                self.run_query(query, parameters)
                
                query ='INSERT INTO ventas VALUES(?, ?, ?)'
                parameters = (self.prodV.get(),self.cantV.get(),self.date.get()) 
                self.run_query(query, parameters)
                self.message['text'] = 'El producto {} se a registrado en ventas exitosamente'.format(self.prodV.get())

                query = 'UPDATE invent SET gana = val * ? WHERE prod = ?'
                parameters = (canti, produ)
                self.run_query(query, parameters)

                self.prodV.delete(0,END)
                self.cantV.delete(0,END)
                self.date.delete(0,END)
                
            else:
                MessageBox.showerror(message='Ingrese el nombre de un producto existente o valor menor que la cantidad actual', title='Ventas')
                self.prodV.delete(0,END)
                self.cantV.delete(0,END)
        else:
            self.message['text'] = 'Porfavor llene todos los parametros'
        self.get_venta()


    '''Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas Ventas'''

#_________________________________________________________________________________________________________________________________

    '''Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias '''
    def Ganancias(self):
        self.wind.withdraw()
        #Variable con nombre de la base de datos
        self.db_name = 'database.db'

        #Config de la ventana de Ganancias
        self.windGan = Toplevel(self.wind)
        self.windGan.geometry("401x260")
        self.windGan['bg'] = '#B4E197'
        self.windGan.wm_resizable(False,False)
        
        #Boton de Volver
        Button(self.windGan, text='volver', command=self.volverGan, bg="#83BD75").grid(row=2)
        
        #Table
        self.tree=ttk.Treeview(self.windGan, height=10,columns=2)
        self.tree.grid(row=1,column=0)
        self.tree.heading('#0', text='Producto', anchor=CENTER)
        self.tree.heading('#1', text='Ganancia', anchor=CENTER)

        self.get_gan()

    def volverGan(self):
        self.windGan.destroy()
        self.wind.deiconify()


    def get_gan(self):
        records=self.tree.get_children()
        for element in records:
            self.tree.delete(element)
        
        #query data
        query = 'SELECT * FROM invent ORDER BY prod DESC'
        db_rows = self.run_query(query)
        for row in db_rows:
            self.tree.insert('',0, text = row[0], values=(row[4]))


    '''Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias Ganancias '''

#_________________________________________________________________________________________________________________________________



if __name__ == '__main__':
    window = Tk()
    Mercado  = index(window)
    window.mainloop()